package cn.wustlinghang.mywust.util;

import java.util.Comparator;

public class RepeatableComparator implements Comparator<String> {
    @Override
    public int compare(String o1, String o2) {
        return 1;
    }
}
