package cn.wustlinghang.mywust.core.request.service.undergraduate;

import cn.wustlinghang.mywust.exception.ApiException;
import cn.wustlinghang.mywust.core.request.factory.undergrade.BkjxRequestFactory;
import cn.wustlinghang.mywust.network.RequestClientOption;
import cn.wustlinghang.mywust.network.Requester;
import cn.wustlinghang.mywust.network.entitys.HttpRequest;
import cn.wustlinghang.mywust.network.entitys.HttpResponse;

import java.io.IOException;
import java.util.Map;

/**
 * 本科培养方案API服务类
 * 用于获取本科学生的培养方案页面内容，封装了与教务系统培养方案相关的网络请求逻辑
 */
public class UndergradTrainingPlanApiService extends UndergradApiServiceBase {

    /**
     * 构造函数，初始化本科培养方案API服务
     * @param requester HTTP请求器，用于发送网络请求
     */
    public UndergradTrainingPlanApiService(Requester requester) {
        super(requester);
    }

    /**
     * 获取本科培养方案页面内容
     * 注意：该方法忽略传入的params参数，因为获取培养方案不需要额外参数
     * @param cookie 用户Cookie，用于身份验证
     * @param params 请求参数（此方法忽略该参数）
     * @param option 请求客户端选项，可设置超时、代理等
     * @return 培养方案页面的HTML内容
     * @throws ApiException 当API请求异常（如Cookie无效）时抛出
     * @throws IOException 当网络请求发生IO异常时抛出
     */
    @Override
    public String getPage(String cookie, Map<String, String> params, RequestClientOption option) throws ApiException, IOException {
        // 忽略params参数，调用带请求选项的getPage方法
        return this.getPage(cookie, option);
    }

    /**
     * 使用默认请求选项获取本科培养方案页面内容
     * 注意：该方法忽略传入的params参数
     * @param cookie 用户Cookie，用于身份验证
     * @param params 请求参数（此方法忽略该参数）
     * @return 培养方案页面的HTML内容
     * @throws ApiException 当API请求异常（如Cookie无效）时抛出
     * @throws IOException 当网络请求发生IO异常时抛出
     */
    @Override
    public String getPage(String cookie, Map<String, String> params) throws ApiException, IOException {
        return this.getPage(cookie, params, null);
    }

    /**
     * 获取本科培养方案页面内容
     * 直接向教务系统发送请求获取培养方案页面，无需额外参数
     * @param cookies 用户Cookie，用于身份验证
     * @param requestClientOption 请求客户端选项，可设置超时、代理等
     * @return 培养方案页面的HTML内容
     * @throws IOException 当网络请求发生IO异常时抛出
     * @throws ApiException 当API请求异常（如Cookie无效）时抛出
     */
    public String getPage(String cookies, RequestClientOption requestClientOption) throws IOException, ApiException {
        // 构建培养方案页面请求
        HttpRequest request = BkjxRequestFactory.trainingPlanPageRequest(cookies);
        // 发送GET请求并获取响应
        HttpResponse response = requester.get(request, requestClientOption);

        // 检查响应有效性（如Cookie是否有效、请求是否成功）
        super.checkResponse(response);

        // 返回响应的HTML内容
        return response.getStringBody();
    }

    /**
     * 使用默认请求选项获取本科培养方案页面内容
     * @param cookies 用户Cookie，用于身份验证
     * @return 培养方案页面的HTML内容
     * @throws IOException 当网络请求发生IO异常时抛出
     * @throws ApiException 当API请求异常（如Cookie无效）时抛出
     */
    public String getPage(String cookies) throws IOException, ApiException {
        return this.getPage(cookies, (RequestClientOption) null);
    }
}