package cn.wustlinghang.mywust.core.request.service.auth;

import cn.wustlinghang.mywust.core.request.factory.undergrade.BkjxRequestFactory;
import cn.wustlinghang.mywust.core.request.service.captcha.solver.CaptchaSolver;
import cn.wustlinghang.mywust.exception.ApiException;
import cn.wustlinghang.mywust.network.RequestClientOption;
import cn.wustlinghang.mywust.network.Requester;
import cn.wustlinghang.mywust.network.entitys.HttpRequest;
import cn.wustlinghang.mywust.network.entitys.HttpResponse;
import cn.wustlinghang.mywust.network.request.RequestFactory;
import cn.wustlinghang.mywust.urls.UndergradUrls;
import cn.wustlinghang.mywust.urls.UnionAuthUrls;
import cn.wustlinghang.mywust.util.PasswordEncoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * 本科教学系统登录服务类
 * 提供两种登录方式：
 * 1. 新版统一认证登录（推荐）：通过学校统一认证中心获取票据，再兑换教学系统Cookie
 * 2. 旧版直接登录：直接与教学系统交互（不推荐，需特殊密码格式）
 */
public class UndergraduateLogin {
    private static final Logger log = LoggerFactory.getLogger(UndergraduateLogin.class);

    private final Requester requester;        // HTTP请求工具
    private final UnionLogin unionLogin;      // 统一认证登录服务依赖

    /**
     * 构造函数：初始化本科教学系统登录服务
     *
     * @param requester     HTTP请求器，用于发送网络请求
     * @param captchaSolver 验证码解析器，处理登录过程中的验证码
     */
    public UndergraduateLogin(Requester requester, CaptchaSolver<String> captchaSolver) {
        this.requester = requester;
        this.unionLogin = new UnionLogin(requester, captchaSolver);
    }

    /**
     * 新版登录方式：通过统一认证系统获取教学系统Cookie
     * 流程：获取统一认证票据 → 使用票据兑换教学系统Cookie → 验证Cookie有效性
     *
     * @param username      学号/用户名
     * @param password      密码
     * @param requestOption HTTP请求配置（如超时时间、代理等）
     * @return 登录成功后的Cookie字符串
     * @throws IOException  网络异常
     * @throws ApiException 业务异常（如密码错误、系统维护等）
     */
    public String getLoginCookie(String username, String password, RequestClientOption requestOption) throws IOException, ApiException {
        // 1. 通过统一认证系统获取服务票据（Service Ticket）
        String serviceTicket = unionLogin.getServiceTicket(
                username,
                password,
                UnionAuthUrls.Service.BKJX_SSO_SERVICE,  // 教学系统的服务标识
                requestOption
        );
        // 2. 使用票据请求教学系统的会话Cookie
        HttpRequest sessionRequest = BkjxRequestFactory.sessionCookieRequest(serviceTicket);
        HttpResponse sessionResponse = requester.get(sessionRequest, requestOption);
        // 检查响应状态码，若为500+则表示系统异常
        if (sessionResponse.getStatusCode() >= HttpResponse.HTTP_SERVER_ERROR) {
            throw new ApiException(ApiException.Code.UNDERGRAD_SYSTEM_ERROR);
        }

        String cookies = sessionResponse.getCookies();

        // 3. 发送一次任意请求，确保Cookie完全生效（部分系统需要预热请求）
        RequestClientOption tmpOption = requestOption != null
                ? requestOption.copy()
                : new RequestClientOption();
        tmpOption.setFollowUrlRedirect(true);  // 允许自动跟随重定向

        // 若响应包含重定向URL，则访问该URL；否则访问教学系统基础URL
        String redirectedUrl = sessionResponse.getHeaders().get("Location");
        if (redirectedUrl != null && cookies != null) {
            HttpRequest redirectedRequest = RequestFactory.makeHttpRequest(redirectedUrl, null, cookies);
            requester.get(redirectedRequest, tmpOption);
        } else {
            HttpRequest anyRequest = RequestFactory.makeHttpRequest(UndergradUrls.BKJX_SESSION_COOKIE_BASE_URL, null, cookies);
            requester.get(anyRequest, tmpOption);
        }

        // 4. 验证Cookie有效性
        this.checkCookie(cookies, requestOption);

        return cookies;
    }

    /**
     * 旧版登录方式：直接与本科教学系统交互（不推荐）
     * 注意：此方式使用特殊密码加密算法，可能与新版密码不同
     *
     * @param username      学号/用户名
     * @param password      密码（旧版加密格式）
     * @param requestOption HTTP请求配置
     * @return 登录成功后的Cookie字符串
     * @throws IOException  网络异常
     * @throws ApiException 业务异常
     */
    public String getLoginCookieLegacy(String username, String password, RequestClientOption requestOption) throws IOException, ApiException {
        // 1. 获取初始Cookie（访问首页）
        HttpRequest indexRequest = BkjxRequestFactory.Legacy.systemIndexRequest();
        HttpResponse indexResponse = requester.get(indexRequest, requestOption);
        String cookie = indexResponse.getCookies();

        // 2. 获取加密用的dataStr参数（旧版登录特有）
        HttpRequest dataStringRequest = BkjxRequestFactory.Legacy.dataStringRequest();
        dataStringRequest.setCookies(cookie);
        HttpResponse dataStringResponse = requester.post(dataStringRequest, requestOption);

        if (dataStringResponse.getBody() == null) {
            log.warn("[mywust]: 本科教学系统旧版登录：获取dataStr时发生错误");
            throw new ApiException(ApiException.Code.UNKNOWN_EXCEPTION);
        }

        String dataString = dataStringResponse.getStringBody();

        // 3. 加密密码并获取登录ticket
        String encoded = PasswordEncoder.legacyPassword(username, password, dataString);
        HttpRequest ticketRequest = BkjxRequestFactory.Legacy.ticketRedirectRequest(encoded, dataStringResponse.getCookies());
        ticketRequest.setCookies(cookie);
        HttpResponse ticketResponse = requester.post(ticketRequest, requestOption);

        if (ticketResponse.getBody() == null) {
            log.warn("[mywust]: 本科教学系统旧版登录：获取登录ticket时发生错误");
            throw new ApiException(ApiException.Code.UNKNOWN_EXCEPTION);
        }

        // 4. 从跳转URL获取最终会话Cookie
        String sessionRedirect = ticketResponse.getHeaders().get("Location");
        if (sessionRedirect == null) {
            throw new ApiException(ApiException.Code.BKJX_LEGACY_LOGIN_PASSWORD_WRONG);
        }

        HttpRequest sessionRequest = BkjxRequestFactory.makeHttpRequest(sessionRedirect);
        HttpResponse sessionResponse = requester.get(sessionRequest, requestOption);

        String cookies = sessionResponse.getCookies();

        // 5. 验证Cookie有效性
        this.checkCookie(cookies, requestOption);

        return cookies;
    }

    /**
     * 验证Cookie有效性（内部方法）
     * 先进行粗检查，再通过访问测试接口进行细检查
     *
     * @param cookies       待验证的Cookie
     * @param requestOption HTTP请求配置
     * @throws ApiException 若Cookie无效或系统异常
     */
    private void checkCookie(String cookies, RequestClientOption requestOption) throws ApiException, IOException {
        // 粗检查：判断Cookie是否为空
        if (!roughCheckCookie(cookies)) {
            log.error("[mywust]: Cookie粗查不通过：{}", cookies);
            throw new ApiException(ApiException.Code.UNKNOWN_EXCEPTION, "登录获取的Cookie无效");
        }

        // 细检查：通过访问测试接口验证Cookie是否真正可用
        if (!testCookie(cookies, requestOption)) {
            log.warn("[mywust]: Cookie检查不通过：{}", cookies);
            throw new ApiException(ApiException.Code.UNKNOWN_EXCEPTION, "登录获取的Cookie无效");
        }
    }

    /**
     * 粗检查Cookie有效性：判断是否为空
     *
     * @param cookies 待检查的Cookie
     * @return true 若Cookie不为空
     */
    private boolean roughCheckCookie(String cookies) {
        return cookies != null;
    }

    /**
     * 通过访问测试接口验证Cookie有效性
     * 根据响应内容判断Cookie是否有效，或是否存在特殊业务异常
     *
     * @param cookies       待验证的Cookie
     * @param option        HTTP请求配置
     * @return true 若Cookie有效
     * @throws IOException  网络异常
     * @throws ApiException 业务异常（如用户被禁用、系统维护等）
     */
    public boolean testCookie(String cookies, RequestClientOption option) throws IOException, ApiException {
        // 访问测试接口（空白页面）
        HttpRequest testRequest = BkjxRequestFactory.makeHttpRequest(UndergradUrls.BKJX_TEST_API, null, cookies);
        HttpResponse testResponse = requester.get(testRequest, option);

        // 空白页正常响应通常很短（如仅换行符）
        if (testResponse.getBody().length < 8) {
            return true;
        }

        String test = testResponse.getStringBody();

        // 根据响应内容判断异常情况
        if (test.contains("script")) {
            return false;  // 包含script可能表示未登录状态
        } else if (test.contains("禁用")) {
            throw new ApiException(ApiException.Code.UNDERGRAD_BANNED_IN_EXCLUSIVE_TIME);  // 用户被禁用
        } else if (test.contains("不存在")) {
            throw new ApiException(ApiException.Code.UNDERGRAD_USERINFO_NOT_EXISTS);  // 用户信息不存在
        } else if (test.contains("500")) {
            throw new ApiException(ApiException.Code.UNDERGRAD_SYSTEM_ERROR);  // 系统内部错误
        }

        return true;
    }

    /**
     * 重载方法：使用默认请求配置验证Cookie
     */
    public boolean testCookie(String cookies) throws IOException, ApiException {
        return this.testCookie(cookies, null);
    }
}