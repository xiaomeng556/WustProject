package cn.wustlinghang.mywust.core.request.service.undergraduate;

import cn.wustlinghang.mywust.urls.UndergradUrls;
import cn.wustlinghang.mywust.core.util.BkjxUtil;
import cn.wustlinghang.mywust.exception.ApiException;
import cn.wustlinghang.mywust.network.RequestClientOption;
import cn.wustlinghang.mywust.network.Requester;
import cn.wustlinghang.mywust.network.entitys.HttpRequest;
import cn.wustlinghang.mywust.network.entitys.HttpResponse;
import cn.wustlinghang.mywust.network.request.RequestFactory;

import java.io.IOException;
import java.util.Map;

/**
 * 本科教务系统API服务基类
 * 提供本科教务系统API访问的基础功能和通用方法
 * 所有本科教务系统相关的服务类应继承此类
 */
public abstract class UndergradApiServiceBase {
    /** HTTP请求器，用于发送网络请求 */
    protected final Requester requester;

    /**
     * 构造函数，初始化本科教务系统API服务基类
     * @param requester HTTP请求器实例，用于实际发送网络请求
     */
    public UndergradApiServiceBase(Requester requester) {
        this.requester = requester;
    }

    /**
     * 检查HTTP响应是否有效
     * 验证响应状态码、响应内容是否存在以及是否需要重新登录
     * @param response HTTP响应对象
     * @throws ApiException 当响应无效时抛出异常：
     *                      - COOKIE_INVALID：Cookie无效或已过期
     *                      - UNDERGRAD_BANNED_IN_EXCLUSIVE_TIME：在系统繁忙时段被封禁
     */
    public void checkResponse(HttpResponse response) throws ApiException {
        // 检查响应是否正确
        boolean cookieInvalid = response.getBody() == null ||
                response.getStatusCode() != HttpResponse.HTTP_OK ||
                BkjxUtil.needLogin(response.getBody());
        if (cookieInvalid) {
            throw new ApiException(ApiException.Code.COOKIE_INVALID);
        } else if (BkjxUtil.isBannedResponse(response)) {
            throw new ApiException(ApiException.Code.UNDERGRAD_BANNED_IN_EXCLUSIVE_TIME);
        }
    }

    /**
     * 验证用户Cookie是否有效
     * 发送测试请求到本科教务系统，根据响应判断Cookie是否有效
     * @param cookie 用户Cookie
     * @param option 请求客户端选项，可设置超时、代理等
     * @throws ApiException 当Cookie无效时抛出异常
     * @throws IOException 当网络请求发生IO异常时抛出
     */
    public void checkCookies(String cookie, RequestClientOption option) throws ApiException, IOException {
        // 创建测试请求
        HttpRequest request = RequestFactory.makeHttpRequest(UndergradUrls.BKJX_TEST_API, null, cookie);
        // 发送请求并获取响应
        HttpResponse response = requester.get(request, option);

        // 检查响应有效性
        this.checkResponse(response);
    }

    /**
     * 使用默认请求选项验证用户Cookie是否有效
     * @param cookie 用户Cookie
     * @throws ApiException 当Cookie无效时抛出异常
     * @throws IOException 当网络请求发生IO异常时抛出
     */
    public void checkCookies(String cookie) throws ApiException, IOException {
        this.checkCookies(cookie, null);
    }

    /**
     * 获取本科教务系统页面内容（抽象方法）
     * 子类必须实现此方法以提供具体的页面获取逻辑
     * @param cookie 用户Cookie
     * @param params 请求参数
     * @param option 请求客户端选项
     * @return 页面内容字符串
     * @throws ApiException 当API请求异常时抛出
     * @throws IOException 当网络请求发生IO异常时抛出
     */
    public abstract String getPage(String cookie, Map<String, String> params, RequestClientOption option) throws ApiException, IOException;

    /**
     * 使用默认请求选项获取本科教务系统页面内容（抽象方法）
     * 子类必须实现此方法以提供具体的页面获取逻辑
     * @param cookie 用户Cookie
     * @param params 请求参数
     * @return 页面内容字符串
     * @throws ApiException 当API请求异常时抛出
     * @throws IOException 当网络请求发生IO异常时抛出
     */
    public abstract String getPage(String cookie, Map<String, String> params) throws ApiException, IOException;
}