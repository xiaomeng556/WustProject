package cn.wustlinghang.mywust.core.request.service.auth;
import cn.hutool.core.util.RandomUtil;
import cn.wustlinghang.mywust.captcha.SolvedImageCaptcha;
import cn.wustlinghang.mywust.captcha.UnsolvedImageCaptcha;
import cn.wustlinghang.mywust.core.request.factory.auth.UnionAuthRequestFactory;
import cn.wustlinghang.mywust.core.request.service.captcha.solver.CaptchaSolver;
import cn.wustlinghang.mywust.data.auth.UnionAuthCaptchaResponse;
import cn.wustlinghang.mywust.data.auth.UnionAuthLoginTicketRequestParam;
import cn.wustlinghang.mywust.exception.ApiException;
import cn.wustlinghang.mywust.network.RequestClientOption;
import cn.wustlinghang.mywust.network.Requester;
import cn.wustlinghang.mywust.network.entitys.HttpRequest;
import cn.wustlinghang.mywust.network.entitys.HttpResponse;
import cn.wustlinghang.mywust.util.PasswordEncoder;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * 统一认证登录服务类
 * 负责通过学校统一认证系统获取服务票据（Service Ticket），用于访问各子系统（如本科教学系统、图书馆系统等）
 */
public class UnionLogin {
    // Jackson JSON解析器，用于处理接口响应的JSON数据
    private static final ObjectMapper objectMapper = new ObjectMapper();
    // 日志记录器，用于记录登录过程中的关键信息和异常
    Logger log = LoggerFactory.getLogger(UnionLogin.class);
    // HTTP请求器，负责发送网络请求（封装了底层HTTP通信逻辑）
    private final Requester requester;
    // 验证码解析器，用于自动识别登录过程中的验证码
    private final CaptchaSolver<String> captchaSolver;

    /**
     * 构造函数：初始化统一认证登录服务
     *
     * @param requester     HTTP请求工具，用于发送GET/POST请求
     * @param captchaSolver 验证码解析器，处理登录过程中的验证码识别
     */
    public UnionLogin(Requester requester, CaptchaSolver<String> captchaSolver) {
        this.requester = requester;
        this.captchaSolver = captchaSolver;
    }
    /**
     * 获取服务票据（Service Ticket）
     * 调用重载方法，默认最大重试次数为5次（当验证码错误时重试）
     *
     * @param username     用户名（如学号）
     * @param password     密码
     * @param serviceUrl   目标服务地址（需要访问的子系统地址，如教学系统）
     * @param requestOption 请求配置（如超时时间、代理等）
     * @return 服务票据（用于兑换目标系统的登录Cookie）
     * @throws IOException  网络请求异常
     * @throws ApiException 业务逻辑异常（如密码错误、验证码错误等）
     */
    public String getServiceTicket(String username, String password, String serviceUrl,
                                   RequestClientOption requestOption
    ) throws IOException, ApiException {
        return this.getServiceTicket(username, password, serviceUrl, 5, requestOption);
    }
    /**
     * 核心方法：获取服务票据（带重试机制）
     * 完整流程：获取验证码 -> 解析验证码 -> 提交用户名密码+验证码 -> 获取票据
     *
     * @param username     用户名
     * @param password     密码
     * @param serviceUrl   目标服务地址
     * @param maxRetry     最大重试次数（验证码错误时生效）
     * @param requestOption 请求配置
     * @return 服务票据
     * @throws IOException  网络请求异常
     * @throws ApiException 业务异常
     */
    public String getServiceTicket(String username, String password, String serviceUrl, int maxRetry,
                                   RequestClientOption requestOption
    ) throws IOException, ApiException {
        // 1. 密码加密：使用系统统一的加密算法处理密码（避免明文传输）
        String encodedPassword = PasswordEncoder.encodePassword(password);
        // 2. 生成验证码ID：随机生成16字节数据并转为16进制字符串，用于标识本次验证码请求
        String captchaId = Hex.encodeHexString(RandomUtil.randomBytes(16));
        // 构建获取验证码的请求（通过工厂类创建标准化请求对象）
        HttpRequest captchaRequest = UnionAuthRequestFactory.loginCaptchaRequest(captchaId);
        // 发送请求获取验证码响应
        HttpResponse captchaResponse = requester.get(captchaRequest, requestOption);
        // 3. 解析验证码响应：将JSON字符串转为Java对象
        String json = captchaResponse.getStringBody();
        UnionAuthCaptchaResponse unionAuthCaptchaResponse = objectMapper.readValue(json, UnionAuthCaptchaResponse.class);
        // 4. 封装未解决的验证码对象：包含验证码图片数据和绑定信息（uid）
        UnsolvedImageCaptcha<String> unsolvedImageCaptcha = new UnsolvedImageCaptcha<>();
        unsolvedImageCaptcha.setBindInfo(unionAuthCaptchaResponse.getUid()); // 绑定本次验证码的唯一标识（uid）
        unsolvedImageCaptcha.setImage(unionAuthCaptchaResponse.getContent()); // 验证码图片数据（Base64编码）
        try {
            // 5. 处理验证码：调用验证码解析器识别验证码内容
            SolvedImageCaptcha<String> solvedImageCaptcha = captchaSolver.solve(unsolvedImageCaptcha);
            // 6. 构建登录请求参数：封装用户名、加密密码、验证码结果等信息
            UnionAuthLoginTicketRequestParam unionAuthLoginTicketRequestParam = new UnionAuthLoginTicketRequestParam();
            unionAuthLoginTicketRequestParam.setUsername(username);
            unionAuthLoginTicketRequestParam.setPassword(encodedPassword);
            unionAuthLoginTicketRequestParam.setService(serviceUrl); // 目标服务地址（用于生成对应系统的票据）
            unionAuthLoginTicketRequestParam.setId(solvedImageCaptcha.getBindInfo()); // 验证码绑定的uid
            unionAuthLoginTicketRequestParam.setCode(solvedImageCaptcha.getResult()); // 解析出的验证码结果
            // 7. 发送登录请求：获取服务票据（ticket）
            HttpRequest ticketRequest = UnionAuthRequestFactory.loginTicketRequest(unionAuthLoginTicketRequestParam);
            HttpResponse ticketResponse = requester.post(ticketRequest, requestOption);
            // 8. 解析登录响应：提取票据（ticket）
            String ticketResponseBody = ticketResponse.getStringBody();
            String ticket = objectMapper.readTree(ticketResponseBody).path("ticket").asText(null);
            // 如果票据为空，说明登录失败，解析失败原因并抛出对应异常
            if (ticket == null) {
                throw this.analyzeFailReason(ticketResponseBody);
            }
            // 成功获取票据，返回给调用方
            return ticket;
        } catch (ApiException e) {
            // 处理验证码错误的重试逻辑：如果是验证码错误且未达最大重试次数，则递归重试
            if (e.getCode() == ApiException.Code.CAPTCHA_WRONG && maxRetry > 0) {
                return this.getServiceTicket(username, password, serviceUrl, maxRetry - 1, requestOption);
            } else {
                // 其他异常（如密码错误）直接抛出
                throw e;
            }
        }
    }

    /**
     * 解析登录失败原因
     * 根据接口返回的错误码，转换为对应的业务异常（便于上层处理）
     *
     * @param response 登录接口的响应内容（JSON字符串）
     * @return 封装后的业务异常
     */
    private ApiException analyzeFailReason(String response) {
        try {
            // 从JSON响应中提取错误码（位于data.code字段）
            String code = objectMapper.readTree(response)
                    .path("data").path("code")
                    .asText("");
            // 根据错误码返回对应异常
            switch (code) {
                case "PASSERROR":
                case "FALSE":
                    return new ApiException(ApiException.Code.UNI_LOGIN_PASSWORD_WRONG); // 密码错误
                case "NOUSER":
                    return new ApiException(ApiException.Code.UNI_LOGIN_USER_NOT_EXISTS); // 用户不存在
                case "USERLOCK":
                    return new ApiException(ApiException.Code.UNI_LOGIN_USER_BANNED); // 用户被锁定
                case "USERDISABLED":
                    return new ApiException(ApiException.Code.UNI_LOGIN_USER_DISABLED); // 用户被禁用
                case "ISMODIFYPASS":
                    return new ApiException(ApiException.Code.UNI_LOGIN_NEED_CHANGE_PASSWORD); // 需要修改密码
                case "USERNOTONLY":
                    return new ApiException(ApiException.Code.UNI_LOGIN_USER_NOT_ONLY); // 用户信息不唯一
                case "NOREGISTER":
                    return new ApiException(ApiException.Code.UNI_LOGIN_NO_REGISTER); // 用户未注册
                case "TWOVERIFY":
                    return new ApiException(ApiException.Code.UNI_LOGIN_NEED_TFA); // 需要二次验证
                case "CODEFALSE":
                    return new ApiException(ApiException.Code.CAPTCHA_WRONG); // 验证码错误
                default:
                    log.warn("未知的登录失败原因，错误码：{}", code);
                    return new ApiException(ApiException.Code.UNKNOWN_EXCEPTION, "未知的错误原因：" + code);
            }
        } catch (Exception e) {
            // 解析错误码过程中发生异常（如JSON格式错误）
            log.warn("解析登录失败原因时出错：{}，响应内容：{}", e, response);
            return new ApiException(ApiException.Code.UNKNOWN_EXCEPTION, e.toString());
        }
    }
}