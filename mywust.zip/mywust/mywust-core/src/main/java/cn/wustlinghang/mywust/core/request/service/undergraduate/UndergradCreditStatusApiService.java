package cn.wustlinghang.mywust.core.request.service.undergraduate;

import cn.wustlinghang.mywust.exception.ApiException;
import cn.wustlinghang.mywust.exception.ParseException;
import cn.wustlinghang.mywust.core.parser.undergraduate.UndergradCreditStatusIndexParser;
import cn.wustlinghang.mywust.core.request.factory.undergrade.BkjxRequestFactory;
import cn.wustlinghang.mywust.network.RequestClientOption;
import cn.wustlinghang.mywust.network.Requester;
import cn.wustlinghang.mywust.network.entitys.HttpRequest;
import cn.wustlinghang.mywust.network.entitys.HttpResponse;

import java.io.IOException;
import java.util.Map;

/**
 * 本科培养方案学分状态查询API服务类
 * 提供访问本科教务系统学分状态查询页面的功能
 * 支持普通和快速两种查询模式，满足不同场景需求
 */
public class UndergradCreditStatusApiService extends UndergradApiServiceBase {
    /** 学分状态索引页面解析器，用于从索引页面提取必要的表单参数 */
    private static final UndergradCreditStatusIndexParser parser = new UndergradCreditStatusIndexParser();
    /**
     * 构造函数，初始化本科培养方案学分状态查询API服务
     * @param requester HTTP请求器，用于发送网络请求
     */
    public UndergradCreditStatusApiService(Requester requester) {
        super(requester);
    }
    /**
     * 获取本科培养方案学分状态页面内容（普通模式）
     * 此方法会先访问索引页面，解析必要参数后再请求学分状态页面
     * @param cookie 用户Cookie，用于身份验证
     * @param params 请求参数（此方法忽略该参数）
     * @param option 请求客户端选项，可设置超时、代理等
     * @return 学分状态页面的HTML内容
     * @throws ApiException 当参数错误、API请求异常或Cookie无效时抛出
     * @throws IOException 当网络请求发生IO异常时抛出
     */
    @Override
    public String getPage(String cookie, Map<String, String> params, RequestClientOption option) throws ApiException, IOException {
        // 忽略params参数，调用三参数版本的getPage方法，使用普通模式
        return this.getPage(cookie, option, false);
    }

    /**
     * 使用默认请求选项获取本科培养方案学分状态页面内容（普通模式）
     * @param cookie 用户Cookie，用于身份验证
     * @param params 请求参数（此方法忽略该参数）
     * @return 学分状态页面的HTML内容
     * @throws ApiException 当参数错误、API请求异常或Cookie无效时抛出
     * @throws IOException 当网络请求发生IO异常时抛出
     */
    @Override
    public String getPage(String cookie, Map<String, String> params) throws ApiException, IOException {
        return this.getPage(cookie, params, null);
    }

    /**
     * 获取本科培养方案学分状态页面内容，支持普通和快速两种模式
     * - 普通模式：先访问索引页面，解析必要参数后再请求学分状态页面
     * - 快速模式：直接请求学分状态页面，可能缺少部分动态内容
     * @param cookie 用户Cookie，用于身份验证
     * @param option 请求客户端选项，可设置超时、代理等
     * @param quick 是否使用快速模式
     * @return 学分状态页面的HTML内容
     * @throws IOException 当网络请求发生IO异常时抛出
     * @throws ApiException 当API请求异常或Cookie无效时抛出
     */
    public String getPage(String cookie, RequestClientOption option, boolean quick) throws IOException, ApiException {
        HttpRequest request;

        if (quick) {
            // 快速模式：直接请求学分状态页面，不获取索引页面参数
            request = BkjxRequestFactory.creditStatusPageRequest(cookie);
        } else {
            // 普通模式：先获取索引页面，解析必要参数后再请求学分状态页面

            // 1. 获取学分状态索引页面
            HttpRequest indexRequest = BkjxRequestFactory.creditStatusIndexPageRequest(cookie);
            HttpResponse indexResponse = requester.get(indexRequest, option);
            this.checkResponse(indexResponse);

            // 2. 从索引页面解析必要的表单参数
            String indexHtml = indexResponse.getStringBody();
            Map<String, String> params;
            try {
                params = parser.parse(indexHtml);
            } catch (ParseException e) {
                // 解析失败通常表示Cookie已过期或无效
                throw new ApiException(ApiException.Code.COOKIE_INVALID);
            }

            // 3. 使用解析出的参数请求学分状态页面
            request = BkjxRequestFactory.creditStatusPageRequest(cookie, params);
        }

        // 发送请求获取学分状态页面
        HttpResponse response = requester.post(request, option);
        this.checkResponse(response);

        return response.getStringBody();
    }
}