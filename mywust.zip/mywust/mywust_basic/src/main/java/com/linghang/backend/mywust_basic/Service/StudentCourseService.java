package com.linghang.backend.mywust_basic.Service;

import com.linghang.backend.mywust_basic.Dao.Course;
import com.linghang.backend.mywust_basic.Mapper.CourseMapper;
import com.linghang.backend.mywust_basic.Mapper.StudentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentCourseService {
    @Autowired
    CourseMapper courseMapper;
    @Autowired
    StudentMapper studentMapper;

}
