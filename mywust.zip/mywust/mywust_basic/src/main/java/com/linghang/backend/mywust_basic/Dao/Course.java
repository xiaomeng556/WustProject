package com.linghang.backend.mywust_basic.Dao;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

// Course.java
@Data
@TableName("course")
public class Course {
    @TableId(type = IdType.AUTO)
    private Long cid; // 课程ID，对应数据库cid字段
    private String courseName; // 课程名称
    private String teacher;    // 教师姓名
    private String teachClass; // 教学班编号
    private Integer startWeek; // 开始周
    private Integer endWeek;   // 结束周
    private Integer weekDay;   // 星期
    private Integer startSection; // 开始节次
    private Integer endSection;   // 结束节次
    private String classroom;     // 教室位置
    private Long studentUid; // 关联的学生ID
}