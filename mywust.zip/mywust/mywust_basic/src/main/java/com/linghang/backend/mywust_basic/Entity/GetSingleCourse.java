package com.linghang.backend.mywust_basic.Entity;
public class GetSingleCourse {
    private String cookie;
    private String data;
    public String getCookie() {
        return cookie;
    }

    public String getData() {
        return data;
    }
}
