package com.linghang.backend.mywust_basic.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.linghang.backend.mywust_basic.Dao.Student;
import org.apache.ibatis.annotations.Param;

public interface StudentMapper extends BaseMapper<Student> {
    //新增学生
    boolean AddNewStudent(Student student);
    //根据学号查询
    Long selectStudentBystudentId(@Param("sid") String sid);
}
