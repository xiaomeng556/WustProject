package com.linghang.catcampus.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.linghang.catcampus.pojo.Admin;
import com.linghang.catcampus.pojo.LoginForm;
import com.linghang.catcampus.service.AdminService;
import com.linghang.catcampus.service.ArticleService;
import com.linghang.catcampus.util.CreateVerifiCodeImage;
import com.linghang.catcampus.util.JwtHelper;
import com.linghang.catcampus.util.MD5;
import com.linghang.catcampus.util.Result;
import com.linghang.catcampus.util.ResultCodeEnum;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

@Tag(name = "管理员系统接口", description = "包含登录、验证码、密码修改等系统级接口等等") // 替代@Api
@RestController
@RequestMapping("/CatCampus/system")
public class SystemController {
    private static final Logger log = LoggerFactory.getLogger(SystemController.class); // 新增日志对象

    @Autowired
    private AdminService adminService;
    @Autowired
    private ArticleService articleService;

    /**
     * 获取文章的分类信息，ID以及name
     * 请求方式：GET
     * @return Map<Integer,String> 使用Result<T>包装
     */
    @Operation(summary = "获取文章分类信息",
                description = "获取所有文章的分类信息，包括ID和名称，面向管理员展示所有分类")
    @GetMapping("/getArticleCategory")
    public Result<?> getCategories(){
        Map<Integer, String> categories = articleService.getCategories();
        //不对结果操作，向管理员展示所有的分类
        return Result.ok(categories);
    }


    /**
     * 更新用户密码接口
     * @param token 用户登录token
     * @param oldPwd 旧密码（明文）
     * @param newPwd 新密码（明文）
     * @return 更新结果
     */
    @Operation(summary = "更新用户密码") // 替代@ApiOperation
    @PostMapping("/updatePwd/{oldPwd}/{newPwd}")
    public Result updatePwd(
            @Parameter(description = "用户登录token", required = true) @RequestHeader("token") String token,
            @Parameter(description = "旧密码（明文）", required = true) @PathVariable("oldPwd") String oldPwd,
            @Parameter(description = "新密码（明文）", required = true) @PathVariable("newPwd") String newPwd
    ) {
        // 校验token是否过期
        if (JwtHelper.isExpiration(token)) {
            return Result.fail().message("token失效，请重新登录后修改密码");
        }

        // 解析用户ID
        Long userId = JwtHelper.getUserId(token);
        // 加密新旧密码（与数据库存储的加密方式一致）
        String encryptedOldPwd = MD5.encrypt(oldPwd);
        String encryptedNewPwd = MD5.encrypt(newPwd);

        // 校验旧密码是否正确
        QueryWrapper<Admin> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id", userId.intValue())
                .eq("password", encryptedOldPwd);
        Admin admin = adminService.getOne(queryWrapper);

        if (admin != null) {
            // 旧密码正确，更新新密码
            admin.setPassword(encryptedNewPwd);
            adminService.saveOrUpdate(admin);
        } else {
            return Result.fail().message("原密码有误，请重新输入");
        }

        return Result.ok();
    }

    @Operation(summary = "通过token获取当前登录用户信息")
    @GetMapping("/getInfo")
    public Result getInfoByToken(
            @Parameter(description = "用户登录token", required = true) @RequestHeader("token") String token
    ) {
        // 校验token是否过期
        if (JwtHelper.isExpiration(token)) {
            return Result.build(null, ResultCodeEnum.TOKEN_ERROR);
        }

        // 解析用户ID并查询用户信息
        Long userId = JwtHelper.getUserId(token);
        Admin admin = adminService.getAdminById(userId);

        // 封装返回数据（避免直接返回敏感字段，可根据需求调整）
        Map<String, Object> resultMap = new LinkedHashMap<>();
        resultMap.put("user", admin);

        return Result.ok(resultMap);
    }

    @Operation(summary = "用户登录接口")
    @PostMapping("/login")
    public Result login(
            @Parameter(description = "登录表单信息（包含用户名、密码、验证码）", required = true) @RequestBody LoginForm loginForm,
            HttpServletRequest request
    ) {
        // 1. 校验验证码
        HttpSession session = request.getSession();
        String sessionVerifiCode = (String) session.getAttribute("verifiCode");
        String loginVerifiCode = loginForm.getVerifiCode();

        // 验证码失效（未获取或已过期）
        if (sessionVerifiCode == null || sessionVerifiCode.isEmpty()) {
            return Result.fail().message("验证码已失效，请刷新后重试");
        }
        // 验证码错误
        if (!sessionVerifiCode.equalsIgnoreCase(loginVerifiCode)) {
            return Result.fail().message("验证码输入错误，请重新输入");
        }
        // 验证通过后移除session中的验证码（避免重复使用）
        session.removeAttribute("verifiCode");

        // 2. 校验用户名和密码
        try {
            Admin admin = adminService.login(loginForm);
            if (admin != null) {
                // 登录成功，生成token（用户ID + 用户类型，此处假设类型为1表示管理员）
                String token = JwtHelper.createToken(admin.getId().longValue(), 1);
                Map<String, Object> resultMap = new LinkedHashMap<>();
                resultMap.put("token", token);
                return Result.ok(resultMap);
            } else {
                throw new RuntimeException("用户名或密码错误");
            }
        } catch (RuntimeException e) {
            log.error("登录失败：{}", e.getMessage()); // 记录登录失败日志
            return Result.fail().message(e.getMessage());
        }
    }

    @Operation(summary = "获取验证码图片")
    @GetMapping("/getVerifiCodeImage")
    public void getVerifiCodeImage(
            HttpServletRequest request,
            HttpServletResponse response
    ) {
        try {
            // 生成验证码图片和文本
            BufferedImage verifiCodeImage = CreateVerifiCodeImage.getVerifiCodeImage();
            String verifiCode = new String(CreateVerifiCodeImage.getVerifiCode());

            // 将验证码文本存入session（有效期由session配置决定）
            HttpSession session = request.getSession();
            session.setAttribute("verifiCode", verifiCode);

            // 将图片响应给前端（JPEG格式）
            response.setContentType("image/jpeg");
            ImageIO.write(verifiCodeImage, "JPEG", response.getOutputStream());
        } catch (IOException e) {
            log.error("生成验证码失败：", e); // 记录验证码生成失败日志
        }
    }
}