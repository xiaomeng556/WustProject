package com.linghang.catcampus.DTO;

import com.linghang.catcampus.pojo.Cat;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public class CatUploadDTO {
    private Cat cat;
    private String coverImageUrl;
    private List<String> photoUrls;

    // Getters and Setters
    public Cat getCat() {
        return cat;
    }



    public String getCoverImageUrl() {
        return coverImageUrl;
    }


    public List<String> getPhotoUrls() {
        return photoUrls;
    }


}