package com.linghang.catcampus.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.linghang.catcampus.DTO.ArticleUpdateDTO;
import com.linghang.catcampus.DTO.ArticleUploadDTO;
import com.linghang.catcampus.pojo.Article;
import com.linghang.catcampus.DTO.ArticleDTO;
import com.linghang.catcampus.util.Result;
import org.apache.ibatis.annotations.Param;
import org.springframework.security.core.parameters.P;

import java.util.Map;

public interface ArticleService extends IService<Article> {
    IPage<ArticleDTO> getArticlesByCategory(Page<ArticleDTO> page,Integer categoryId, String keyWord,boolean adminTag,Article.Status status);

    Article selectById(Integer articleId);

    Map<Integer,String> getCategories();

    boolean uploadArticle(ArticleUploadDTO uploadDTO);

    boolean deleteById(Integer articleId);

    boolean updateArticleStatus(Integer articleId, Article.Status status);

    Result<?> updateArticle(ArticleUpdateDTO articleUpdateDTO);
}
