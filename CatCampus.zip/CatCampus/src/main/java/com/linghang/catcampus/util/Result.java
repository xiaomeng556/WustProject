package com.linghang.catcampus.util;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * 全局统一返回结果类
 */
@Data
@Schema(name = "全局统一返回结果", description = "封装接口返回的状态码、消息和数据")
public class Result<T> {

    @Schema(description = "返回状态码（200表示成功，其他表示失败）", example = "200")
    private Integer code;

    @Schema(description = "返回消息（成功或失败的描述）", example = "操作成功")
    private String message;

    @Schema(description = "返回数据（成功时返回的业务数据，失败时可能为null）")
    private T data;

    public Result() {}

    // 构建带数据的返回结果
    protected static <T> Result<T> build(T data) {
        Result<T> result = new Result<>();
        if (data != null) {
            result.setData(data);
        }
        return result;
    }

    // 构建带数据和状态码的返回结果
    public static <T> Result<T> build(T body, ResultCodeEnum resultCodeEnum) {
        Result<T> result = build(body);
        result.setCode(resultCodeEnum.getCode());
        result.setMessage(resultCodeEnum.getMessage());
        return result;
    }

    // 成功返回（无数据）
    public static <T> Result<T> ok() {
        return ok(null);
    }

    /**
     * 成功返回（带数据）
     * @param data 业务数据
     * @param <T> 数据类型
     * @return 统一结果对象
     */
    public static <T> Result<T> ok(T data) {
        return build(data, ResultCodeEnum.SUCCESS);
    }

    // 失败返回（无数据）
    public static <T> Result<T> fail() {
        return fail(null);
    }

    /**
     * 失败返回（带数据）
     * @param data 错误相关数据（可选）
     * @param <T> 数据类型
     * @return 统一结果对象
     */
    public static <T> Result<T> fail(T data) {
        return build(data, ResultCodeEnum.FAIL);
    }

    // 链式设置消息
    public Result<T> message(String msg) {
        this.setMessage(msg);
        return this;
    }

    // 链式设置状态码
    public Result<T> code(Integer code) {
        this.setCode(code);
        return this;
    }

    // 判断是否成功（根据状态码）
    public boolean isOk() {
        return this.getCode().intValue() == ResultCodeEnum.SUCCESS.getCode().intValue();
    }

    public Result data(T items, T respMap) {
        return null;
    }
}