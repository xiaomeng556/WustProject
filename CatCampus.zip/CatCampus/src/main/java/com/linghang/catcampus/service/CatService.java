package com.linghang.catcampus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.linghang.catcampus.pojo.Cat;

import java.util.List;

public interface CatService extends IService<Cat> {
    boolean addCat(Cat cat);
    boolean updateCat(Cat cat);
    boolean deleteCat(int id);
    Cat info(int id);
    List<Cat> findByName(String name);
    List<Cat> list();
    boolean uploadCatWithPhotos(Cat cat, String coverImageUrl, List<String> photoUrls);
}

