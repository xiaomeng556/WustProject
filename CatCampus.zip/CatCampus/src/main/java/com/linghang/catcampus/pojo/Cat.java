package com.linghang.catcampus.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.security.Timestamp;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("cat")
public class Cat {

    public enum AdoptState {
        yes,no
    }

    @TableId(value = "id",type = IdType.AUTO)
    private int id;
    private String name;
    private Date birth_data;
    private String variety;
    private String adoptMessage;
    private AdoptState adoptState;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private List<Photo> photos;

}
