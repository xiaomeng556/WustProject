package com.linghang.catcampus.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.linghang.catcampus.DTO.ArticleUpdateDTO;
import com.linghang.catcampus.DTO.ArticleUploadDTO;
import com.linghang.catcampus.mapper.ArticleMapper;
import com.linghang.catcampus.pojo.Article;
import com.linghang.catcampus.DTO.ArticleDTO;
import com.linghang.catcampus.pojo.Photo;
import com.linghang.catcampus.service.ArticleService;
import com.linghang.catcampus.util.AliOSSUtil;
import com.linghang.catcampus.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service("articleService")
@Transactional
public class ArticleServiceImpl extends ServiceImpl<ArticleMapper, Article> implements ArticleService {

    @Autowired
    private ArticleMapper articleMapper;

    @Override
    public IPage<ArticleDTO> getArticlesByCategory(Page<ArticleDTO> page, Integer categoryId,String keyWord,boolean adminTag,Article.Status status) {
        return articleMapper.selectArticlesByCategory(page, categoryId, keyWord,adminTag, status);
    }

    @Override
    public Article selectById(Integer articleId) {
        return articleMapper.selectById(articleId);
    }

    @Override
    public Map<Integer, String> getCategories() {
        return articleMapper.getCategories();
    }

    @Override
    public boolean uploadArticle(ArticleUploadDTO uploadDTO) {
        // Validate the uploadDTO fields
        if (uploadDTO.getTitle() == null || uploadDTO.getTitle().isEmpty()) {
            throw new IllegalArgumentException("Title cannot be empty");
        }
        if (uploadDTO.getContent() == null || uploadDTO.getContent().isEmpty()) {
            throw new IllegalArgumentException("Content cannot be empty");
        }
        if (uploadDTO.getCategoryId() == null || uploadDTO.getCategoryId() <= 0) {
            throw new IllegalArgumentException("Invalid category ID");
        }

        try {
            Article article = new Article();
            article.setTitle(uploadDTO.getTitle());
            article.setContent(uploadDTO.getContent());
            article.setExcerpt(uploadDTO.getExcerpt());
            article.setAuthor(uploadDTO.getAuthor());
//            article.setStatus(Article.Status.valueOf("unreviewed")); // 默认状态为未审核

            //插入、获取文章信息及数据库中唯一ID
            int insert = baseMapper.insert(article);
            if(insert <= 0) {
                throw new RuntimeException("Failed to insert article");
            }

            Integer articleId = article.getId();
            if (uploadDTO.getCoverImage() != null && !uploadDTO.getCoverImage().isEmpty()) {
                String coverImageUrl = uploadImage(uploadDTO.getCoverImage());
                // 更新文章的封面图片路径
                Article updateArticle = new Article();
                updateArticle.setId(articleId);
//                updateArticle.setCoverImagePath(coverImageUrl);

                Photo photo = new Photo();
                photo.setPath(coverImageUrl);
                articleMapper.saveCoverPhoto(photo);
                int id = photo.getId();
                updateArticle.setCoverPhotoId(id);

                baseMapper.updateById(updateArticle);
            }

            // 3. 上传其他图片并保存到数据库
            if (uploadDTO.getPhotos() != null && !uploadDTO.getPhotos().isEmpty()) {
                for (MultipartFile photo : uploadDTO.getPhotos()) {
                    if (!photo.isEmpty()) {
                        String photoUrl = uploadImage(photo);
                        // 保存照片到photo表
                        articleMapper.insertPhoto(articleId, photoUrl);
                    }
                }
            }

            // 4. 保存文章分类关联
            articleMapper.insertArticleCategory(articleId, uploadDTO.getCategoryId());

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to upload article: " + e.getMessage());
        }
    }

    // 删除图片、删除文章
    @Override
    public boolean deleteById(Integer articleId) {
        try {
            // 1. 获取文章信息
            Article article = baseMapper.selectById(articleId);
            if (article == null) {
                System.out.println("Article not found with ID: " + articleId);
                return false;
            }

            // 2. 获取所有需要删除的图片路径
            List<String> imageUrls = new ArrayList<>();

            // 2.1 获取封面图片路径
            if (article.getCoverPhotoId() != null) {
                String coverPath = articleMapper.selectCoverPhotoPathById(article.getCoverPhotoId());
                if (coverPath != null) {
                    imageUrls.add(coverPath);
                }
            }

            // 2.2 获取内容图片路径
            List<String> contentPaths = articleMapper.selectPhotoPathsByArticleId(articleId);
            if (contentPaths != null && !contentPaths.isEmpty()) {
                imageUrls.addAll(contentPaths);
            }

            // 3. 删除阿里云OSS上的图片
            for (String imageUrl : imageUrls) {
                if (imageUrl != null && !imageUrl.isEmpty()) {
                    deleteOSSImage(imageUrl);
                }
            }

            // 4. 删除数据库记录（注意顺序）
            // 4.1 先删除封面图片记录
            if (article.getCoverPhotoId() != null) {
                articleMapper.deletePhotoById(article.getCoverPhotoId());
            }

            // 4.2 删除内容图片记录
            articleMapper.deleteContentPhotosByArticleId(articleId);

            // 4.3 删除文章分类关联
            articleMapper.deleteArticleCategory(articleId);

            // 4.4 删除文章本身
            int result = baseMapper.deleteById(articleId);

            return result > 0;
        } catch (Exception e) {
            throw new RuntimeException("删除文章失败", e);
        }
    }

    //更新文章状态，用于审核通过或拒绝
    @Override
    public boolean updateArticleStatus(Integer articleId, Article.Status status) {
        try {
            Article article = new Article();
            article.setId(articleId);
            article.setStatus(status);
            int result = baseMapper.updateById(article);
            return result > 0;
        } catch (Exception e) {
            throw new RuntimeException("更新文章状态失败", e);
        }
    }

    @Override
    public Result<?> updateArticle(ArticleUpdateDTO articleUpdateDTO) {
        if(articleUpdateDTO==null||articleUpdateDTO.getId()==null||articleUpdateDTO.getId()<=0) {
            return Result.fail().message("Invalid article data");
        }

        Article article = new Article();
        article.setId(articleUpdateDTO.getId());
        article.setTitle(articleUpdateDTO.getTitle());
        article.setContent(articleUpdateDTO.getContent());
        article.setExcerpt(articleUpdateDTO.getExcerpt());
//        article.setCategoryId(articleUpdateDTO.getCategoryId());
        article.setAuthor(articleUpdateDTO.getAuthor());
        article.setStatus(Article.Status.valueOf("unreviewed"));
        // 更新文章信息
        int result = baseMapper.updateById(article);

        //更改文章分类
        boolean bool = articleMapper.deleteArticleCategory(articleUpdateDTO.getId());
        int i = articleMapper.insertArticleCategory(articleUpdateDTO.getId(), articleUpdateDTO.getCategoryId());

        return i > 0 && bool ? Result.ok().message("文章更新成功") : Result.fail().message("文章更新失败");
    }

    // 删除OSS图片的辅助方法
    private void deleteOSSImage(String imageUrl) {
            // 从URL中提取objectName
            String objectName = AliOSSUtil.extractObjectNameFromUrl(imageUrl);
            // 调用OSS删除方法
            AliOSSUtil.deleteFile(objectName);
    }

    //上传图片辅助方法
    private String uploadImage(MultipartFile file) throws IOException {
        String objectName = "article/" + UUID.randomUUID() + getFileExtension(file.getOriginalFilename());
        try (InputStream inputStream = file.getInputStream()) {
            return AliOSSUtil.uploadFile(objectName, inputStream);
        }
    }

    //上传图片辅助方法
    private String getFileExtension(String filename) {
        if (filename == null || filename.lastIndexOf(".") == -1) {
            return "";
        }
        return filename.substring(filename.lastIndexOf("."));
    }
}
