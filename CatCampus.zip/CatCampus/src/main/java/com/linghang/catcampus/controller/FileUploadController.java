package com.linghang.catcampus.controller;

import com.linghang.catcampus.util.AliOSSUtil;
import com.linghang.catcampus.util.Result;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

@RestController
@RequestMapping(value = "/CatCampus/file")
public class FileUploadController {

    @RequestMapping(method = RequestMethod.POST, value = "/upload")
    public Result<?> upload(MultipartFile file) throws IOException {
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || originalFilename.isEmpty()) {
            return Result.fail().message("File name cannot be empty");
        }
        String originalFileType = originalFilename.substring(originalFilename.lastIndexOf("."));
        String filename = UUID.randomUUID() + originalFileType;
        String url = AliOSSUtil.uploadFile(filename, file.getInputStream());

        if (url == null || url.isEmpty()) {
            return Result.fail().message("File upload failed");
        }
        return Result.ok(url);
    }
}