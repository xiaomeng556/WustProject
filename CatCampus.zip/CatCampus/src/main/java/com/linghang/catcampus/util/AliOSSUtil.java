package com.linghang.catcampus.util;

import com.aliyun.oss.*;
import com.aliyun.oss.model.PutObjectRequest;
import com.aliyun.oss.model.PutObjectResult;
import org.mybatis.logging.Logger;
import org.mybatis.logging.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.io.InputStream;

@Component
public class AliOSSUtil {

    // bucket概述：访问端口-外网访问-Endpoint（地域节点）
    @Value("${aliyun.oss.endpoint}")
    private static String ENDPOINT = "oss-cn-beijing.aliyuncs.com";

    // 密钥
    @Value("${aliyun.oss.accessKeyId}")
    private static String ACCESS_KEY_ID = "LTAI5tCEWimPgyMDs9yWKDUx";
    @Value("${aliyun.oss.accessKeySecret}")
    private static String ACCESS_KEY_SECRET = "D32xfiBbaWosCXrPfEHZmVHRrGRl3T";

    // bucket概述：存储空间名称
    @Value("${aliyun.oss.bucketName}")
    private static String BUCKET_NAME = "cat-photo";

    // objectName: 图片名称(包含后缀),  in: 输入流
    public static String uploadFile(String objectName, InputStream in) {
        // 创建OSSClient实例。
        OSS ossClient = new OSSClientBuilder().build(ENDPOINT,ACCESS_KEY_ID,ACCESS_KEY_SECRET);
        // 返回OSS图片地址
        String url = "";
        try {
            // 创建PutObjectRequest对象。
            PutObjectRequest putObjectRequest = new PutObjectRequest(BUCKET_NAME, objectName, in);
            // 创建PutObject请求。
            PutObjectResult result = ossClient.putObject(putObjectRequest);
            // 文件上传成功后外网访问地址。 示例: https://bucket-yangyang-one.oss-cn-qingdao.aliyuncs.com/1.png
            url = "https://" + BUCKET_NAME + "." + ENDPOINT.substring(ENDPOINT.lastIndexOf("/")+1) + "/" + objectName;
        } catch (OSSException oe) {
            System.out.println("Caught an OSSException, which means your request made it to OSS, "
                    + "but was rejected with an error response for some reason.");
            System.out.println("Error Message:" + oe.getErrorMessage());
            System.out.println("Error Code:" + oe.getErrorCode());
            System.out.println("Request ID:" + oe.getRequestId());
            System.out.println("Host ID:" + oe.getHostId());
        } catch (ClientException ce) {
            System.out.println("Caught an ClientException, which means the client encountered "
                    + "a serious internal problem while trying to communicate with OSS, "
                    + "such as not being able to access the network.");
            System.out.println("Error Message:" + ce.getMessage());
        } finally {
            if (ossClient != null) {
                ossClient.shutdown();
            }
        }
        return url;
    }

    // 删除文件
    public static void deleteFile(String objectName) {
        // 创建OSSClient实例
        OSS ossClient = new OSSClientBuilder().build(ENDPOINT, ACCESS_KEY_ID, ACCESS_KEY_SECRET);
        try {
            // 删除文件
            ossClient.deleteObject(BUCKET_NAME, objectName);
        } catch (OSSException oe) {
            System.out.println("Caught an OSSException, which means your request made it to OSS, "
                    + "but was rejected with an error response for some reason.");
            System.out.println("Error Message:" + oe.getErrorMessage());
            System.out.println("Error Code:" + oe.getErrorCode());
            System.out.println("Request ID:" + oe.getRequestId());
            System.out.println("Host ID:" + oe.getHostId());
        } catch (ClientException ce) {
            System.out.println("Caught an ClientException, which means the client encountered "
                    + "a serious internal problem while trying to communicate with OSS, "
                    + "such as not being able to access the network.");
            System.out.println("Error Message:" + ce.getMessage());
        } finally {
            if (ossClient != null) {
                ossClient.shutdown();
            }
        }

    }

    // 从URL中提取objectName
    public static String extractObjectNameFromUrl(String url) {
        // URL格式: https://bucket-name.endpoint/objectName
        if (url == null || url.isEmpty()) return "";

        String prefix = "https://" + AliOSSUtil.BUCKET_NAME + "." + AliOSSUtil.ENDPOINT + "/";
        if (url.startsWith(prefix)) {
            return url.substring(prefix.length());
        }
        return url;
    }

}
