package com.linghang.catcampus.DTO;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Data
public class ArticleUploadDTO {
    private String title;
    private String content;
    private String excerpt;
    private String author;
    private Integer categoryId;
    private MultipartFile coverImage;
    private List<MultipartFile> photos;
}