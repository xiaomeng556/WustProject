package com.linghang.catcampus.util;

import com.linghang.catcampus.pojo.UserInfo;
import com.linghang.catcampus.service.impl.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

@Service
public class GetEntitify {

    @Autowired
    TokenService tokenService;
    private static UserInfo getUidandUsername() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserInfo user) {
            return user;
        }
        return null;
    }

}
