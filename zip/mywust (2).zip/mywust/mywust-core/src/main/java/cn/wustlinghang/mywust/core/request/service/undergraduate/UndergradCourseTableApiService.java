package cn.wustlinghang.mywust.core.request.service.undergraduate;

import cn.wustlinghang.mywust.exception.ApiException;
import cn.wustlinghang.mywust.core.request.factory.undergrade.BkjxRequestFactory;
import cn.wustlinghang.mywust.network.RequestClientOption;
import cn.wustlinghang.mywust.network.Requester;
import cn.wustlinghang.mywust.network.entitys.HttpRequest;
import cn.wustlinghang.mywust.network.entitys.HttpResponse;

import java.io.IOException;
import java.util.Map;

/**
 * 本科课程表API服务类，用于获取本科学生的课程表信息
 * 该类提供了多种获取课程表页面的方法，支持不同的参数组合和请求选项
 */
public class UndergradCourseTableApiService extends UndergradApiServiceBase {

    /**
     * 获取课程表页面时必需的参数列表
     * 当前仅需学期(term)参数
     */
    private static final String[] NECESSARY_PARAMS = {"term"};

    /**
     * 构造函数，初始化本科课程表API服务
     * @param requester HTTP请求器，用于发送网络请求
     */
    public UndergradCourseTableApiService(Requester requester) {
        super(requester);
    }

    /**
     * 通过参数Map获取课程表页面内容
     * @param cookie 用户Cookie，用于身份验证
     * @param params 请求参数，必须包含NECESSARY_PARAMS中的参数
     * @param option 请求客户端选项，可设置超时、代理等
     * @return 课程表页面的HTML内容
     * @throws ApiException 当参数错误或API请求异常时抛出
     * @throws IOException 当网络请求发生IO异常时抛出
     */
    @Override
    public String getPage(String cookie, Map<String, String> params, RequestClientOption option) throws ApiException, IOException {
        // 检查必要参数是否存在
        for (String key : NECESSARY_PARAMS) {
            if (params.get(key) == null) {
                throw new ApiException(ApiException.Code.PARAM_WRONG_EXCEPTION);
            }
        }

        // 调用更具体的获取页面方法
        return this.getPage(params.get(NECESSARY_PARAMS[0]), cookie, option);
    }

    /**
     * 通过参数Map获取课程表页面内容，使用默认请求选项
     * @param cookie 用户Cookie，用于身份验证
     * @param params 请求参数，必须包含NECESSARY_PARAMS中的参数
     * @return 课程表页面的HTML内容
     * @throws ApiException 当参数错误或API请求异常时抛出
     * @throws IOException 当网络请求发生IO异常时抛出
     */
    @Override
    public String getPage(String cookie, Map<String, String> params) throws ApiException, IOException {
        return this.getPage(cookie, params, null);
    }

    /**
     * 通过学期参数获取课程表页面内容
     * @param term 学期参数，如"2023-2024-1"
     * @param cookies 用户Cookie，用于身份验证
     * @param requestClientOption 请求客户端选项，可设置超时、代理等
     * @return 课程表页面的HTML内容
     * @throws IOException 当网络请求发生IO异常时抛出
     * @throws ApiException 当API请求异常时抛出
     */
    public String getPage(String term, String cookies, RequestClientOption requestClientOption) throws IOException, ApiException {
        // 构建课程表页面请求
        HttpRequest request = BkjxRequestFactory.courseTablePageRequest(term, cookies);
        // 发送POST请求并获取响应
        HttpResponse response = requester.post(request, requestClientOption);

        // 检查响应状态和内容是否正常
        super.checkResponse(response);

        // 返回响应的HTML内容
        return response.getStringBody();
    }

    /**
     * 通过学期参数获取课程表页面内容，使用默认请求选项
     * @param term 学期参数，如"2023-2024-1"
     * @param cookies 用户Cookie，用于身份验证
     * @return 课程表页面的HTML内容
     * @throws IOException 当网络请求发生IO异常时抛出
     * @throws ApiException 当API请求异常时抛出
     */
    public String getPage(String term, String cookies) throws IOException, ApiException {
        return getPage(term, cookies, null);
    }
}