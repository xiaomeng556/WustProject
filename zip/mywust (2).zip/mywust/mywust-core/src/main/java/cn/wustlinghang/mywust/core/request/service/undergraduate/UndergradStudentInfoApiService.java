package cn.wustlinghang.mywust.core.request.service.undergraduate;

import cn.wustlinghang.mywust.exception.ApiException;
import cn.wustlinghang.mywust.core.request.factory.undergrade.BkjxRequestFactory;
import cn.wustlinghang.mywust.network.RequestClientOption;
import cn.wustlinghang.mywust.network.Requester;
import cn.wustlinghang.mywust.network.entitys.HttpRequest;
import cn.wustlinghang.mywust.network.entitys.HttpResponse;

import java.io.IOException;
import java.util.Map;

/**
 * 本科生个人信息API服务类
 * 封装了与本科教务系统中个人信息相关的网络请求逻辑，用于获取学生基本信息页面内容
 */
public class UndergradStudentInfoApiService extends UndergradApiServiceBase {

    /**
     * 构造函数，初始化本科生个人信息API服务
     * @param requester HTTP请求器，用于发送网络请求
     */
    public UndergradStudentInfoApiService(Requester requester) {
        super(requester);
    }

    /**
     * 获取学生个人信息页面内容
     * 注意：该方法忽略传入的params参数，因为获取个人信息无需额外参数（信息与登录账号绑定）
     * @param cookie 用户Cookie，用于身份验证（关联具体学生账号）
     * @param params 请求参数（此方法忽略该参数）
     * @param option 请求客户端选项，可设置超时、代理等网络配置
     * @return 学生个人信息页面的HTML内容
     * @throws ApiException 当API请求异常（如Cookie无效、登录状态过期）时抛出
     * @throws IOException 当网络请求发生IO异常（如连接失败、读取超时）时抛出
     */
    @Override
    public String getPage(String cookie, Map<String, String> params, RequestClientOption option) throws ApiException, IOException {
        // 忽略参数，调用带请求选项的具体实现方法
        return this.getPage(cookie, option);
    }

    /**
     * 使用默认请求选项获取学生个人信息页面内容
     * 注意：该方法忽略传入的params参数
     * @param cookie 用户Cookie，用于身份验证
     * @param params 请求参数（此方法忽略该参数）
     * @return 学生个人信息页面的HTML内容
     * @throws ApiException 当API请求异常时抛出
     * @throws IOException 当网络请求发生IO异常时抛出
     */
    @Override
    public String getPage(String cookie, Map<String, String> params) throws ApiException, IOException {
        return this.getPage(cookie, params, null);
    }

    /**
     * 获取学生个人信息页面内容的核心实现
     * 直接向教务系统个人信息接口发送请求，基于Cookie关联的账号获取对应信息
     * @param cookies 用户Cookie，用于身份验证（包含登录状态信息）
     * @param requestOption 请求客户端选项，可配置网络参数
     * @return 学生个人信息页面的HTML内容（包含姓名、学号、专业等基本信息）
     * @throws IOException 当网络请求发生IO异常时抛出
     * @throws ApiException 当响应验证失败（如Cookie无效）时抛出
     */
    public String getPage(String cookies, RequestClientOption requestOption) throws IOException, ApiException {
        // 构建个人信息页面请求（由请求工厂处理URL和请求头配置）
        HttpRequest request = BkjxRequestFactory.studentInfoRequest(cookies);
        // 发送GET请求并获取响应
        HttpResponse response = requester.get(request, requestOption);

        // 检查响应有效性（验证登录状态、响应状态码等）
        super.checkResponse(response);

        // 返回响应体中的HTML内容
        return response.getStringBody();
    }

    /**
     * 使用默认请求选项获取学生个人信息页面内容
     * @param cookies 用户Cookie，用于身份验证
     * @return 学生个人信息页面的HTML内容
     * @throws IOException 当网络请求发生IO异常时抛出
     * @throws ApiException 当API请求异常时抛出
     */
    public String getPage(String cookies) throws IOException, ApiException {
        return this.getPage(cookies, (RequestClientOption) null);
    }
}