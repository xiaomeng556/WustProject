package cn.wustlinghang.mywust.core.request.service.auth;
import cn.wustlinghang.mywust.captcha.SolvedImageCaptcha;
import cn.wustlinghang.mywust.captcha.UnsolvedImageCaptcha;
import cn.wustlinghang.mywust.core.request.factory.graduate.GraduateRequestFactory;
import cn.wustlinghang.mywust.core.request.service.captcha.solver.CaptchaSolver;
import cn.wustlinghang.mywust.exception.ApiException;
import cn.wustlinghang.mywust.network.RequestClientOption;
import cn.wustlinghang.mywust.network.Requester;
import cn.wustlinghang.mywust.network.entitys.HttpRequest;
import cn.wustlinghang.mywust.network.entitys.HttpResponse;
import cn.wustlinghang.mywust.network.request.RequestFactory;
import cn.wustlinghang.mywust.urls.GraduateUrls;
import lombok.extern.slf4j.Slf4j;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * 研究生系统登录服务类
 * 负责处理研究生系统的登录流程，包括验证码获取与解析、登录请求发送及Cookie验证
 */
@Slf4j
public class GraduateLogin {
    private final Requester requester;                // HTTP请求工具，用于发送网络请求
    private final CaptchaSolver<byte[]> captchaSolver; // 验证码解析器，处理字节数组类型的验证码图片

    /**
     * 构造函数：初始化研究生登录服务
     *
     * @param requester     HTTP请求器，负责底层网络通信
     * @param captchaSolver 验证码解析器，用于识别登录验证码
     */
    public GraduateLogin(Requester requester, CaptchaSolver<byte[]> captchaSolver) {
        this.requester = requester;
        this.captchaSolver = captchaSolver;
    }

    /**
     * 核心登录方法：获取研究生系统登录Cookie
     * 流程：访问登录页获取初始Cookie → 获取并处理验证码 → 提交登录信息 → 验证登录结果
     *
     * @param username  用户名（如研究生学号）
     * @param password  密码
     * @param option    HTTP请求配置（如超时时间、代理等）
     * @return 登录成功后的Cookie字符串
     * @throws IOException  网络请求异常
     * @throws ApiException 业务异常（如验证码错误、密码错误等）
     */
    public String getLoginCookie(String username, String password, RequestClientOption option) throws IOException, ApiException {
        // 1. 访问登录首页，获取初始会话Cookie
        HttpRequest loginIndexRequest = RequestFactory.makeHttpRequest(GraduateUrls.GRADUATE_LOGIN_API);
        HttpResponse loginIndexResponse = requester.get(loginIndexRequest, option);
        String loginCookie = loginIndexResponse.getCookies();

        // 2. 使用初始Cookie请求验证码图片
        HttpRequest captchaImageRequest = GraduateRequestFactory.captchaRequest(loginCookie);
        HttpResponse captchaImageResponse = requester.get(captchaImageRequest, option);

        // 3. 封装未解析的验证码对象（包含Cookie绑定信息和处理后的图片）
        UnsolvedImageCaptcha<byte[]> unsolvedImageCaptcha = new UnsolvedImageCaptcha<>();
        unsolvedImageCaptcha.setBindInfo(loginCookie); // 绑定当前会话的Cookie
        // 处理验证码图片（去色、二值化，增强识别率）
        byte[] processedImage = ImageUtil.process(captchaImageResponse.getBody());
        unsolvedImageCaptcha.setImage(processedImage);

        // 4. 调用验证码解析器识别验证码
        SolvedImageCaptcha<byte[]> solvedImageCaptcha = captchaSolver.solve(unsolvedImageCaptcha);

        // 5. 提交登录请求（包含用户名、密码、验证码等信息）
        String loginIndexHtml = loginIndexResponse.getStringBody(); // 登录页HTML（可能包含隐藏参数）
        HttpRequest loginRequest = GraduateRequestFactory.loginRequest(
                username, password, loginIndexHtml, solvedImageCaptcha
        );
        HttpResponse loginResponse = requester.post(loginRequest, option);

        // 6. 验证登录结果（登录成功会返回302重定向）
        if (loginResponse.getStatusCode() != HttpResponse.HTTP_REDIRECT_302) {
            String responseHtml = loginResponse.getStringBody();
            // 根据响应内容判断具体错误
            if (responseHtml.contains("验证码错误")) {
                throw new ApiException(ApiException.Code.GRADUATE_CAPTCHA_WRONG);
            } else if (responseHtml.contains("密码错误") || responseHtml.contains("用户名不存在")) {
                throw new ApiException(ApiException.Code.GRADUATE_PASSWORD_WRONG);
            } else {
                throw new ApiException(ApiException.Code.UNKNOWN_EXCEPTION);
            }
        }

        // 返回登录成功的Cookie（初始Cookie已在登录过程中激活）
        return loginCookie;
    }

    /**
     * 带重试机制的登录方法（对外接口）
     * 指定最大重试次数，当登录失败时自动重试
     *
     * @param username    用户名
     * @param password    密码
     * @param maxRetryTimes 最大重试次数
     * @param option      请求配置
     * @return 登录Cookie
     * @throws IOException  网络异常
     * @throws ApiException 业务异常（重试耗尽后抛出）
     */
    public String getLoginCookie(String username, String password, int maxRetryTimes, RequestClientOption option)
            throws IOException, ApiException {
        // 调用私有重载方法，初始重试计数为0
        return getLoginCookie(username, password, maxRetryTimes, 0, option);
    }

    /**
     * 带重试机制的登录方法（私有实现）
     * 递归实现重试逻辑，仅在非验证码错误且未达最大重试次数时重试
     *
     * @param username    用户名
     * @param password    密码
     * @param maxRetryTimes 最大重试次数
     * @param cnt         当前重试计数
     * @param option      请求配置
     * @return 登录Cookie
     * @throws IOException  网络异常
     * @throws ApiException 业务异常
     */
    private String getLoginCookie(String username, String password, int maxRetryTimes, int cnt, RequestClientOption option)
            throws IOException, ApiException {
        try {
            // 尝试登录
            return getLoginCookie(username, password, option);
        } catch (ApiException e) {
            // 判断是否需要重试：未达最大次数且不是验证码错误
            boolean shouldRetry = (cnt < maxRetryTimes) && (e.getCode() != ApiException.Code.GRADUATE_CAPTCHA_WRONG);
            if (shouldRetry) {
                log.info("[mywust]: 第{}次重试登录", cnt + 1);
                return getLoginCookie(username, password, maxRetryTimes, cnt + 1, option);
            } else {
                // 无需重试，抛出异常
                throw e;
            }
        }
    }

    /**
     * 验证Cookie有效性
     * 通过访问研究生系统首页测试Cookie是否可用
     *
     * @param cookie 待验证的Cookie
     * @param option 请求配置
     * @throws IOException  网络异常
     * @throws ApiException 若Cookie无效则抛出异常
     */
    public void checkCookies(String cookie, RequestClientOption option) throws ApiException, IOException {
        HttpRequest request = RequestFactory.makeHttpRequest(GraduateUrls.GRADUATE_INDEX_TEST_API, null, cookie);
        HttpResponse response = requester.get(request, option);
        this.checkResponse(response);
    }

    /**
     * 验证响应内容判断Cookie有效性
     * 若响应为空、状态码非200，或包含登录表单字段，则视为Cookie无效
     *
     * @param response 测试请求的响应
     * @throws ApiException 若Cookie无效则抛出异常
     */
    public void checkResponse(HttpResponse response) throws ApiException {
        if (response.getBody() == null ||
                response.getStatusCode() != HttpResponse.HTTP_OK ||
                new String(response.getBody()).contains("name=\"_ctl0:txtpassword\"")) { // 包含密码输入框表示未登录
            throw new ApiException(ApiException.Code.COOKIE_INVALID);
        }
    }
}

/**
 * 验证码图片处理工具类
 * 提供验证码图片预处理功能（去色、二值化），增强OCR识别率
 */
class ImageUtil {
    // 验证码图片固定尺寸（宽x高）
    private static final int IMAGE_WIDTH = 75;
    private static final int IMAGE_HEIGHT = 35;

    // 二值化阈值：像素亮度低于此值视为黑色，否则为白色（实测339效果最佳）
    private static final int LIMIT = 339;

    // 黑白二值化的颜色常量
    private static final int BLACK = Color.BLACK.getRGB();
    private static final int WHITE = Color.WHITE.getRGB();

    /**
     * 处理验证码图片：将彩色图片转为黑白二值化图片
     * 增强图片对比度，便于验证码识别
     *
     * @param data 原始验证码图片的字节数组
     * @return 处理后的图片字节数组（PNG格式）
     * @throws ApiException 图片处理失败时抛出
     */
    public static byte[] process(byte[] data) throws ApiException {
        try {
            // 1. 将字节数组转为BufferedImage
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(data);
            BufferedImage bufferedImage = ImageIO.read(byteArrayInputStream);

            // 2. 遍历每个像素，进行二值化处理
            for (int i = 0; i < IMAGE_WIDTH; ++i) {
                for (int j = 0; j < IMAGE_HEIGHT; ++j) {
                    int rgb = bufferedImage.getRGB(i, j);
                    // 计算像素亮度（RGB三通道亮度之和）
                    int bright = ((rgb >> 16) & 0xff) + ((rgb >> 8) & 0xff) + (rgb & 0xff);
                    // 根据亮度阈值设置黑白像素
                    bufferedImage.setRGB(i, j, bright <= LIMIT ? BLACK : WHITE);
                }
            }

            // 3. 将处理后的图片转为字节数组
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            ImageIO.write(bufferedImage, "png", outputStream);

            return outputStream.toByteArray();
        } catch (Exception e) {
            throw new ApiException(ApiException.Code.INTERNAL_EXCEPTION);
        }
    }
}