package cn.wustlinghang.mywust.core.test;

import cn.wustlinghang.mywust.core.parser.undergraduate.UndergradCourseTableParser;
import cn.wustlinghang.mywust.core.parser.undergraduate.UndergradScoreParser;
import cn.wustlinghang.mywust.core.parser.undergraduate.UndergradTrainingPlanPageParser;
import cn.wustlinghang.mywust.core.request.service.auth.UndergraduateLogin;
import cn.wustlinghang.mywust.core.request.service.auth.UnionLogin;
import cn.wustlinghang.mywust.core.request.service.captcha.solver.builtin.DdddOcrBase64ImgExprCaptchaSolver;
import cn.wustlinghang.mywust.core.request.service.undergraduate.UndergradCourseTableApiService;
import cn.wustlinghang.mywust.core.request.service.undergraduate.UndergradScoreApiService;
import cn.wustlinghang.mywust.core.request.service.undergraduate.UndergradTrainingPlanApiService;
import cn.wustlinghang.mywust.core.util.WustRequester;
import cn.wustlinghang.mywust.data.common.Course;
import cn.wustlinghang.mywust.data.common.Score;
import cn.wustlinghang.mywust.exception.ApiException;
import cn.wustlinghang.mywust.exception.ParseException;
import cn.wustlinghang.mywust.network.RequestClientOption;
import cn.wustlinghang.mywust.network.Requester;
import cn.wustlinghang.mywust.network.entitys.HttpRequest;
import cn.wustlinghang.mywust.network.entitys.HttpResponse;
import cn.wustlinghang.mywust.urls.UnionAuthUrls;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class main {
    public static void main(String args[]) throws IOException, ApiException, ParseException {
        System.out.println("武科大助手后端basic测试入口");
        new main().getTraningPlan();
    }
    void getTraningPlan() throws IOException, ApiException, ParseException {
        //获取培养方案
        //请求选项
        RequestClientOption requestClientOption = new RequestClientOption();
        requestClientOption.setTimeout(10);
        requestClientOption.setFollowUrlRedirect(false);
        requestClientOption.setRetryable(true);
        requestClientOption.setMaxRetryTimes(3);
        requestClientOption.setIgnoreSSLError(true);
        //请求器
        WustRequester requester=new WustRequester();
        //获取cookie
        UndergraduateLogin undergraduateLogin=new UndergraduateLogin(requester,new DdddOcrBase64ImgExprCaptchaSolver());
        String cookie=undergraduateLogin.getLoginCookie("202313201025","JAYCHOUcr7..",requestClientOption);
        //获取服务
        UndergradTrainingPlanApiService undergradTrainingPlanApiService=new UndergradTrainingPlanApiService(requester);
        //解析器
        UndergradTrainingPlanPageParser parser=new UndergradTrainingPlanPageParser();
        String page= undergradTrainingPlanApiService.getPage(cookie);
        String result=parser.parse(page);
       System.out.println(result);
    }
    void getAllCourse(){

    }
}
