package cn.wustlinghang.mywust.core.request.service.undergraduate;

import cn.wustlinghang.mywust.exception.ApiException;
import cn.wustlinghang.mywust.core.request.factory.undergrade.BkjxRequestFactory;
import cn.wustlinghang.mywust.network.RequestClientOption;
import cn.wustlinghang.mywust.network.Requester;
import cn.wustlinghang.mywust.network.entitys.HttpRequest;
import cn.wustlinghang.mywust.network.entitys.HttpResponse;

import java.io.IOException;
import java.util.Map;

/**
 * 本科成绩查询API服务类
 * 提供访问本科教务系统成绩查询页面的功能
 * 该类封装了成绩查询相关的网络请求逻辑
 */
public class UndergradScoreApiService extends UndergradApiServiceBase {

    /**
     * 构造函数，初始化本科成绩查询API服务
     * @param requester HTTP请求器，用于发送网络请求
     */
    public UndergradScoreApiService(Requester requester) {
        super(requester);
    }

    /**
     * 获取本科成绩查询页面内容
     * 注意：该方法忽略传入的params参数，因为成绩查询不需要额外参数
     * @param cookie 用户Cookie，用于身份验证
     * @param params 请求参数（此方法忽略该参数）
     * @param option 请求客户端选项，可设置超时、代理等
     * @return 成绩查询页面的HTML内容
     * @throws ApiException 当参数错误或API请求异常时抛出
     * @throws IOException 当网络请求发生IO异常时抛出
     */
    @Override
    public String getPage(String cookie, Map<String, String> params, RequestClientOption option) throws ApiException, IOException {
        // 忽略params参数，直接调用无参的getPage方法
        return this.getPage(cookie, option);
    }

    /**
     * 获取本科成绩查询页面内容，使用默认请求选项
     * 注意：该方法忽略传入的params参数
     * @param cookie 用户Cookie，用于身份验证
     * @param params 请求参数（此方法忽略该参数）
     * @return 成绩查询页面的HTML内容
     * @throws ApiException 当参数错误或API请求异常时抛出
     * @throws IOException 当网络请求发生IO异常时抛出
     */
    @Override
    public String getPage(String cookie, Map<String, String> params) throws ApiException, IOException {
        return this.getPage(cookie, params, null);
    }

    /**
     * 获取本科成绩查询页面内容
     * 发送请求到教务系统获取成绩信息页面
     * @param cookies 用户Cookie，用于身份验证
     * @param requestClientOption 请求客户端选项，可设置超时、代理等
     * @return 成绩查询页面的HTML内容
     * @throws IOException 当网络请求发生IO异常时抛出
     * @throws ApiException 当API请求异常时抛出
     */
    public String getPage(String cookies, RequestClientOption requestClientOption) throws IOException, ApiException {
        // 构建成绩查询请求，此处使用空参数表示获取所有成绩
        HttpRequest request = BkjxRequestFactory.examScoreInfoRequest(cookies, "", "", "");
        // 发送POST请求并获取响应
        HttpResponse response = requester.post(request, requestClientOption);

        // 检查响应状态和内容是否正常
        super.checkResponse(response);

        // 返回响应的HTML内容
        return response.getStringBody();
    }

    /**
     * 获取本科成绩查询页面内容，使用默认请求选项
     * @param cookies 用户Cookie，用于身份验证
     * @return 成绩查询页面的HTML内容
     * @throws IOException 当网络请求发生IO异常时抛出
     * @throws ApiException 当API请求异常时抛出
     */
    public String getPage(String cookies) throws IOException, ApiException {
        return this.getPage(cookies, (RequestClientOption) null);
    }
}