# Mywust common

存放各种数据实体类等公共依赖