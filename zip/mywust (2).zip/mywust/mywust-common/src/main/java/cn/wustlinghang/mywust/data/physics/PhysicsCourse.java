package cn.wustlinghang.mywust.data.physics;

import cn.wustlinghang.mywust.data.common.Course;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PhysicsCourse extends Course {
    private String date;
}
