package cn.wustlinghang.mywust.data.common;

public interface WithIdData {
    String getId();
}
