package cn.wustlinghang.mywust.data.auth;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UnionAuthCaptchaResponse {
    private String uid;

    private String content;

    private Integer timeout;
}