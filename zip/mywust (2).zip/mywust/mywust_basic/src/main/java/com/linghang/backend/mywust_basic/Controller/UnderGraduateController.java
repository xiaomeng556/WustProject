package com.linghang.backend.mywust_basic.Controller;
import cn.wustlinghang.mywust.core.parser.undergraduate.*;
import cn.wustlinghang.mywust.core.request.service.auth.UndergraduateLogin;
import cn.wustlinghang.mywust.core.request.service.undergraduate.*;
import cn.wustlinghang.mywust.core.util.WustRequester;
import cn.wustlinghang.mywust.data.common.Course;
import cn.wustlinghang.mywust.data.common.Score;
import cn.wustlinghang.mywust.data.common.StudentInfo;
import cn.wustlinghang.mywust.exception.ApiException;
import cn.wustlinghang.mywust.exception.ParseException;
import cn.wustlinghang.mywust.network.RequestClientOption;
import com.linghang.backend.mywust_basic.Entity.UnderGraduateLoginA;
import com.linghang.backend.mywust_basic.Service.TokenService;
import com.linghang.backend.mywust_basic.Utils.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;
import java.util.List;
import java.util.Map;
@Tag(name = "本科生接口", description = "提供课程、成绩、考试等功能接口")
@RestController
@RequestMapping("/UnderGraduateStudent")
public class UnderGraduateController {
    private  String This_term="2024-2025-2";
    @Autowired
    private TokenService tokenService;
    private final WustRequester wustRequester;
    private final UndergraduateLogin undergraduateLogin;
    private final RequestClientOption requestClientOption;
    UndergradStudentInfoApiService MystudentInfoApiService;
    UndergradStudentInfoPageParser StudentInfoparser;
    //自动注入
    @Autowired
    public UnderGraduateController(WustRequester wustRequester,
                                   UndergraduateLogin undergraduateLogin,
                                   RequestClientOption requestClientOption) {
        this.wustRequester = wustRequester;
        this.undergraduateLogin = undergraduateLogin;
        this.requestClientOption = requestClientOption;
         MystudentInfoApiService=new UndergradStudentInfoApiService(wustRequester);
         StudentInfoparser=new UndergradStudentInfoPageParser();
    }
    //登录
    @Operation(summary = "登录本科生系统", description = "返回登录成功后的 Cookie")
    @PostMapping("/login")
    public R<String> login(@RequestBody UnderGraduateLoginA loginA) {
        try {
            String username = loginA.getUsername();
            String password = loginA.getPassword();
            // 获取登录后的 Cookie
            String cookie = undergraduateLogin.getLoginCookie(username, password, null);
            // 生成 JWT Token 并缓存 cookie
            String token = tokenService.createToken(username, cookie);
            try {
                String page = MystudentInfoApiService.getPage(cookie);
                StudentInfo studentInfo = StudentInfoparser.parse(page);
                tokenService.createUidToken(token,loginA.getUsername());
                tokenService.createName(token,studentInfo.getName());
            }catch (Exception e){
                e.printStackTrace();
                return R.failure(500,"error");
            }
            return R.success(token);  //cr 返回JWT Token给客户端
        } catch (Exception e) {
            e.printStackTrace();
            return R.failure(500, e.getMessage());
        }
    }
    @Operation(summary = "获取个人信息", description = "返回获取的个人信息")
    @GetMapping("/getStudentInfo")
    public R<StudentInfo> getStudentInfo()  {
        String cookie = getCookieFromSecurityContext();
        UndergradStudentInfoApiService studentInfoApiService=new UndergradStudentInfoApiService(wustRequester);
        UndergradStudentInfoPageParser parser=new UndergradStudentInfoPageParser();
        try {
            String page = studentInfoApiService.getPage(cookie);
            StudentInfo studentInfo = parser.parse(page);
            return R.success(studentInfo);
        }catch (Exception e){
            e.printStackTrace();
            return R.failure(500,"error");
        }
    }
    //查学期课程
    @Operation(summary = "获取成绩", description = "获取当前用户所有已出成绩")
    @GetMapping("/UnderGraduateGetScore")
    public R<List<Score>> getScores() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (!(principal instanceof String cookie)) {
            return R.failure(401, "Unauthorized");
        }
        return getListR(cookie);
    }
    @Operation(summary = "获取所有课程表", description = "获取此学期课程信息")
    @GetMapping("/UnderGraduateGetCourses")
    R<List<Course>> UnderGraduateGetCourses(){
        String cookie = getCookieFromSecurityContext();
        try {
            UndergradCourseTableApiService courseTableApiService=new UndergradCourseTableApiService(wustRequester);
            UndergradCourseTableParser courseTableParser=new UndergradCourseTableParser();
            String page=courseTableApiService.getPage(This_term,cookie);
            List<Course> courseList = courseTableParser.parse(page);
            return R.success(courseList);
        }catch (Exception e){
            e.printStackTrace();
            return R.failure(500,e.getMessage());
        }
    }
    @Operation(summary = "获取单天课程表", description = "获取某天/某周的课程信息")
    @GetMapping("/UnderGraduateGetSingleCourses")
    R<List<Course>> GetSingleCourses(@RequestParam("date") String data){
        try {
            List<Course> courseList=getSingleCourseList(data,getCookieFromSecurityContext());
            return R.success(courseList);
        }catch (Exception e){
            e.printStackTrace();
            return R.failure(500,e.getMessage());
        }
    }

    @Operation(summary = "获取培养方案", description = "返回 HTML 格式的培养方案内容")
    @GetMapping("/UnderGraduateTrainingPlan")
    public R<String> GetTrainningPlan() {
        String cookie = getCookieFromSecurityContext();
        if (cookie == null) return R.failure(401, "Unauthorized");
        try {
            UndergradTrainingPlanApiService service = new UndergradTrainingPlanApiService(wustRequester);
            UndergradTrainingPlanPageParser parser = new UndergradTrainingPlanPageParser();
            String page = service.getPage(cookie);
            String plan = parser.parse(page);
            return R.success(plan);
        } catch (Exception e) {
            e.printStackTrace();
            return R.failure(500, e.getMessage());
        }
    }

    @Operation(summary = "获取学分修读情况", description = "获取总学分和通识选修等修读信息")
    @GetMapping("/GetCreditStatus")
    public R<Map<String, CreditStatusParser.CourseInfo>> GetCreditStatus() {
        String cookie = getCookieFromSecurityContext();
        if (cookie == null) return R.failure(401, "Unauthorized");
        try {
            String page= CreditStatusPageGet.GetPage(cookie);
            Map<String, CreditStatusParser.CourseInfo> stringStringMap=CreditStatusParser.Parse(page);
            return R.success(stringStringMap);
        } catch (Exception e) {
            e.printStackTrace();
            return R.failure(500, e.getMessage());
        }
    }
    @Operation(summary = "获取毕业要求情况", description = "获取毕业要求及完成情况")
    @GetMapping("/GetGraduateRequireParse")
    public R<Map<String, Object>> GetGraduateRequireParse() {
        String cookie = getCookieFromSecurityContext();
        if (cookie == null) return R.failure(401, "Unauthorized");
        try {
            String page= CreditStatusPageGet.GetPage(cookie);
            Map<String, Object> graduateRequire= GraduateRequireParser.Parse(page);
            return R.success(graduateRequire);
        } catch (Exception e) {
            e.printStackTrace();
            return R.failure(500, e.getMessage());
        }
    }

    @Operation(summary = "获取考试安排", description = "返回指定学期的考试安排")
    @GetMapping("/GetExam")
    R<String> GetExam(@RequestParam("term") String term){
        try {
            String cookie = getCookieFromSecurityContext();
            return R.success(ExamFetcher.GetExamPage(term,cookie));
        }catch (Exception e){
            e.printStackTrace();
            return R.failure(500,e.getMessage());
        }
    }
    private String getCookieFromSecurityContext() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof String cookie) {
            return cookie;
        }
        return null;
    }
    //获取成绩表
    @NotNull
    private R<List<Score>> getListR(String cookie) {
        try {
            UndergradScoreApiService apiService = new UndergradScoreApiService(wustRequester);
            UndergradScoreParser parser = new UndergradScoreParser();
            String page = apiService.getPage(cookie);
            List<Score> scoreList = parser.parse(page);
            return R.success(scoreList);
        } catch (Exception e) {
            e.printStackTrace();
            return R.failure(500, e.getMessage());
        }
    }

    List<Course> getSingleCourseList(String data,String cookie) throws IOException, ApiException, ParseException {
        UndergradSingleWeekCourseApiService undergradSingleWeekCourseApiService=new UndergradSingleWeekCourseApiService(wustRequester);
        UndergradSingleWeekCourseParser parser=new UndergradSingleWeekCourseParser();
        String page=undergradSingleWeekCourseApiService.getPage(data,cookie);
        List<Course> courseList= parser.parse(page);
        return  courseList;
    }
}
