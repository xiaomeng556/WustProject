package com.linghang.backend.mywust_basic.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.linghang.backend.mywust_basic.Dao.Course;

import java.util.List;

public interface CourseMapper extends BaseMapper<Course> {
    //新增课程
    boolean AddCourse(Course course);
    //根据uid查询
    List<Course> SelectByUid(Long uid);
}
