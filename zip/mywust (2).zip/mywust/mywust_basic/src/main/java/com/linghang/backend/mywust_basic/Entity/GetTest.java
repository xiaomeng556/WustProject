package com.linghang.backend.mywust_basic.Entity;

public class GetTest {
    private String cookie;
    private String term;

    public String getCookie() {
        return cookie;
    }

    public String getTerm() {
        return term;
    }
}
