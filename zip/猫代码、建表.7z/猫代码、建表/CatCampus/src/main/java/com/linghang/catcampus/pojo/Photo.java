package com.linghang.catcampus.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("photo")
public class Photo {
    @TableId(value = "id",type = IdType.AUTO)
    private int id;
    private String path;
    private String storage_type;
    private int cat_id;
    private int article_id;
    private Timestamp created_at;
}
