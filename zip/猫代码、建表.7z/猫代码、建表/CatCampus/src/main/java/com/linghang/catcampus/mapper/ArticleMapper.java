package com.linghang.catcampus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.linghang.catcampus.pojo.Article;
import com.linghang.catcampus.DTO.ArticleDTO;
import com.linghang.catcampus.pojo.Photo;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

@Mapper
public interface ArticleMapper extends BaseMapper<Article> {
    IPage<ArticleDTO> selectArticlesByCategory(@Param("page")  Page<ArticleDTO> page,
                                               @Param("categoryId") Integer categoryId,
                                               @Param("keyWord") String keyWord,
                                               @Param("adminTag") boolean adminTag,
                                               @Param("status") Article.Status status);

    Article selectById(@Param("articleId") Integer articleId);

    @MapKey("id")
    Map<Integer, String> getCategories();

    // ArticleMapper.java
    // 插入文章-分类关联
    int insertArticleCategory(@Param("articleId") Integer articleId, @Param("categoryId") Integer categoryId);

    // 插入照片
    int insertPhoto(@Param("articleId") Integer articleId, @Param("path") String path);

    int saveCoverPhoto(Photo photo);

    // ArticleMapper.java
    @Delete("DELETE FROM photo WHERE id = #{id}")
    void deletePhotoById(@Param("id") Integer id);

    @Select("SELECT path FROM photo WHERE article_id = #{articleId}")
    List<String> selectPhotoPathsByArticleId(@Param("articleId") Integer articleId);

    @Select("SELECT path FROM photo WHERE id = #{coverPhotoId}")
    String selectCoverPhotoPathById(@Param("coverPhotoId") Integer coverPhotoId);

    @Delete("DELETE FROM article_category WHERE article_id = #{articleId}")
    boolean deleteArticleCategory(@Param("articleId") Integer articleId);

//    @Insert("INSERT INTO article_category (article_id, category_id) VALUES (#{articleId}, #{categoryId})")
//    int insertArticleCategory(@Param("articleId") Integer articleId, @Param("categoryId") Integer categoryId);

    @Delete("DELETE FROM photo WHERE article_id = #{articleId}")
    void deleteContentPhotosByArticleId(@Param("articleId") Integer articleId);



}
