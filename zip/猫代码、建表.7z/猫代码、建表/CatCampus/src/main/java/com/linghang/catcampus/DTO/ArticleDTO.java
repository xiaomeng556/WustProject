package com.linghang.catcampus.DTO;

import com.linghang.catcampus.pojo.Article;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ArticleDTO {
    private Integer id;
    private String title;
//    private String content;
    private Article.Status status;
    private String excerpt;
    private String author;
    private String coverImagePath;
//    private boolean adminTag; // 是否为管理员操作

}
