package com.linghang.catcampus.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.linghang.catcampus.pojo.Admin;
import com.linghang.catcampus.service.AdminService;
import com.linghang.catcampus.util.MD5;
import com.linghang.catcampus.util.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "管理员控制器", description = "管理员相关的CRUD接口") // 替代@Api
@RestController
@RequestMapping("/CatCampus/adminController")
public class AdminController {
    // 初始化日志对象（补充之前缺失的log）
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    private AdminService adminService;

    @Operation(summary = "分页带条件查询管理员信息") // 替代@ApiOperation
    @GetMapping("/getAllAdmin/{pageNo}/{pageSize}")
    public Result<?> getAllAdmin(
            @Parameter(description = "页码数，从1开始", required = true) @PathVariable("pageNo") Integer pageNo, // 替代@ApiParam
            @Parameter(description = "页大小", required = true) @PathVariable("pageSize") Integer pageSize,
            @Parameter(description = "管理员名字（可选）") @RequestParam(required = false) String adminName
    ) {
        // 参数校验
        if (pageNo == null || pageNo < 1) {
            return Result.fail("页码数不能小于1");
        }
        if (pageSize == null || pageSize <= 0) {
            return Result.fail("页大小必须大于0");
        }

        // 分页参数转换
        Page<Admin> pageParam = new Page<>(pageNo, pageSize);

        try {
            IPage<Admin> iPage = adminService.getAdminsByOpr(pageParam, adminName);
            return Result.ok(iPage);
        } catch (Exception e) {
            log.error("查询管理员列表失败", e); // 补充日志打印
            return Result.fail("查询管理员列表失败，请稍后重试");
        }
    }

    @Operation(summary = "增加或修改管理员信息")
    @PostMapping("/saveOrUpdateAdmin")
    public Result<?> saveOrUpdateAdmin(
            @Parameter(description = "JSON格式的Admin对象", required = true) @RequestBody Admin admin
    ) {
        Integer id = admin.getId();
        if (id == null || id == 0) {
            admin.setPassword(MD5.encrypt(admin.getPassword())); // 新增时加密密码
        }
        adminService.saveOrUpdate(admin);
        return Result.ok();
    }

    @Operation(summary = "删除单个或多个管理员信息")
    @PostMapping("/deleteAdmin")
    public Result<?> deleteAdmin(
            @Parameter(description = "要删除的管理员ID集合", required = true) @RequestParam List<Integer> ids
    ) {
        adminService.removeByIds(ids);
        return Result.ok();
    }
}