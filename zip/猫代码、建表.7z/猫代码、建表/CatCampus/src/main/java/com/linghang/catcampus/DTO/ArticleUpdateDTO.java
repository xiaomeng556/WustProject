package com.linghang.catcampus.DTO;

import com.linghang.catcampus.pojo.Article;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ArticleUpdateDTO {
    private Integer id;
    private String title;
    private String content;
    private String excerpt;
    private Integer categoryId;
    private String author;
//    private Article.Status status;
}
