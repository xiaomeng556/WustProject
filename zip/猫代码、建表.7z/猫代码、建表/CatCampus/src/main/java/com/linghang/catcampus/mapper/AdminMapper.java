package com.linghang.catcampus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.linghang.catcampus.pojo.Admin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface AdminMapper extends BaseMapper<Admin> {
    @Options(useGeneratedKeys = true,keyProperty = "id")
    boolean addAdmin(Admin admin);
}
