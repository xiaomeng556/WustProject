package com.linghang.catcampus.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.linghang.catcampus.DTO.ArticleDTO;
import com.linghang.catcampus.DTO.ArticleUpdateDTO;
import com.linghang.catcampus.DTO.ArticleUploadDTO;
import com.linghang.catcampus.pojo.Article;
import com.linghang.catcampus.service.ArticleService;
import com.linghang.catcampus.util.JwtUtils;
import com.linghang.catcampus.util.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Tag(name = "文章管理接口",description = "提供文章的增删改查等功能")
@RestController
@RequestMapping("/CatCampus/article")
public class ArticleController {

    @Autowired
    private ArticleService articleService;

    /**
    * 获取文章列表、使用分类信息<br>
    * 请求方式：GET
    * @param pageNo 页码
    * @param pageSize 每页大小
    * @param categoryId 分类ID
    * @param keyWord 关键词模糊查询标题和概要以及作者
    * @return IPage<ArticleDTO> 使用Result<T>包装
    * */
    @Operation(
            summary = "获取文章列表",
            description = "根据分类ID和关键词获取文章列表，支持分页<br>" +
                    "关键词：对于概述和标题，是模糊匹配；对于作者（学号），是精准匹配<br>" +
                    "同时，我加了一个adminTag参数(boolean)，用于判断是否为管理员操作<br>" +
                    "如果是管理员操作，则应当传入一个枚举类status参数，用于限制查询出来的文章的状态（approved、unreviewed），" +
                    "所以应当在后台提供一个选择文章状态的按钮。<br>" +
                    "@return IPage<ArticleDTO> 使用Result<T>包装"
    )
    @GetMapping("/getArticleList/{pageNo}/{pageSize}")
    public Result<?> getArticlesByCategory(
            @PathVariable("pageNo") Integer pageNo,
            @PathVariable("pageSize") Integer pageSize,
            @RequestParam Integer categoryId,
            @RequestParam(required = false) String keyWord,
            @RequestParam("adminTag") boolean adminTag,
            @RequestParam(required = false) Article.Status status//不是必须传入，判断是否为管理员在操作，避免数据泄露（？
    ) {
        if(pageNo == null || pageNo < 1) {
            return Result.fail().message("Page number must be greater than 0");
        }

        if(pageSize == null || pageSize <= 0) {
            return Result.fail().message("Page size must be greater than 0");
        }

        if (categoryId == null || categoryId <= 0) {
            return Result.fail().message("Invalid category ID");
        }

        if (keyWord != null && keyWord.isEmpty()) {
            keyWord = null; // 如果关键词为空，则不进行模糊查询
        }
        Page<ArticleDTO> page = new Page<>(pageNo,pageSize);

        return Result.ok(articleService.getArticlesByCategory(page,categoryId,keyWord,adminTag, status));
    }

    /**
     * 获取文章详情界面信息，在获取列表时已经获取了文章在数据库中的ID<br>
     * 请求方式：GET
     * @param articleId 文章ID
     * @return Article 使用Result<T>包装
     */
    @Operation(
            summary = "获取文章详情",
            description = "根据文章ID获取文章的详细信息，面向用户，只获取已审核的文章信息" +
                    "<p>@return Article 使用Result<T>包装</p>"
    )
    @GetMapping("/getArticleDetail/{articleId}")
    public Result<?> getArticleDetail(@PathVariable("articleId") Integer articleId){
        if(articleId == null || articleId <= 0) {
            return Result.fail().message("Invalid article ID");
        }
        Article article = articleService.selectById(articleId);
        if (article == null) {
            return Result.fail().message("Article not found");
        } else if (article.getStatus()!= Article.Status.approved) {
            return Result.fail().message("Article is not approved yet");
        } else {
            return Result.ok(article);
        }
    }

    /**
     * 获取文章的分类信息，ID以及name<br>
     * 请求方式：GET
     * @return Map<Integer,String> 使用Result<T>包装
     */
    @Operation(
            summary = "获取文章分类",
            description = "获取所有文章分类的ID和名称，并对普通用户限制了分类ID为1的募捐通道分类的访问权限<br>" +
                    "@return Map<Integer,String> 使用Result<T>包装"
    )
    @GetMapping("/getArticleCategory")
    public Result<?> getCategories(){
        Map<Integer, String> categories = articleService.getCategories();
        categories.remove(1); // 移除ID为3的分类，即募捐通道，普通用户创作文章无法使用此通道
        return Result.ok(categories);
    }

    /**
     * 上传文章信息：article信息、类别信息、封面信息、照片数组信息<br>
     * 请求方式：POST
     * @param articleUploadDTO 包含文章标题、内容、类别ID等信息
     * @return Result<?> 成功或失败的信息
     */
    @Operation(
            summary = "上传文章",
            description = "上传文章信息，包括标题、内容、类别ID等，面向用户的创作界面使用<br>" +
                    "注意：文章的封面图片和内容图片需要在前端处理成MultipartFile格式上传，<br>" +
                    "期望图片等信息临时存储在前端页面，在用户点击确认按钮之后再将数据传到后端<br>" +
                    "并且需要在ArticleUploadDTO中包含封面图片和内容图片的相关信息"
    )
    @PostMapping("/uploadArticle")
    public Result<?> uploadArticle(@ModelAttribute ArticleUploadDTO articleUploadDTO) {
        if (articleUploadDTO == null) {
            return Result.fail().message("Article upload data is missing");
        }

        if (articleUploadDTO.getTitle() == null || articleUploadDTO.getTitle().isEmpty()) {
            return Result.fail().message("Title cannot be empty");
        }

        if (articleUploadDTO.getContent() == null || articleUploadDTO.getContent().isEmpty()) {
            return Result.fail().message("Content cannot be empty");
        }

        if (articleUploadDTO.getCategoryId() == null || articleUploadDTO.getCategoryId() <= 0) {
            return Result.fail().message("Invalid category ID");
        }

        try {
            boolean result = articleService.uploadArticle(articleUploadDTO);
            return result ? Result.ok().message("Article uploaded successfully") : Result.fail().message("Failed to upload article");
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail().message("Error occurred while uploading article: " + e.getMessage());
        }
    }

    /**
     * 删除文章以及相关图片<br>
     * 请求方式：DELETE
     * @param articleId 文章ID
     * @return Result<?> 成功或失败的信息
     */
    @Operation(
            summary = "删除文章",
            description = "根据文章ID删除文章及其相关图片，从本地到云端一键删除。"
    )
    @DeleteMapping("/deleteArticle/{articleId}")
    public Result<?> deleteArticle(@PathVariable("articleId") Integer articleId){
        if(articleId == null) {
            return Result.fail().message("Invalid article ID");
        }

        boolean result = articleService.deleteById(articleId);
        return result ? Result.ok().message("Article deleted successfully") : Result.fail().message("Failed to delete article");
    }


    /**
     * 文章的内容更新功能，先调用详细信息接口，再实现更新，仅实现部分内容的更新<br>
     * 请求方式：PATCH
     * @param articleUpdateDTO 包含文章ID、标题、内容、类别ID等信息
     * @return Result<?> 成功或失败的信息
     */
    @Operation(
            summary = "更新文章",
            description = "调用了JwtUtils中的获取ID方法，从请求头的Authorization中获取<br>" +
                    "期望获得学号与作者身份校验（作者身份在创作界面期望能自动填入学号并且不可更改）。"
    )
    @PatchMapping("/updateArticle")
    public Result<?> updateArticle(@RequestBody ArticleUpdateDTO articleUpdateDTO, HttpServletRequest request){

        String authorization = request.getHeader("Authorization");
        String userIdFromToken = JwtUtils.getUserIdFromToken(authorization);

        if(!userIdFromToken.equals(articleUpdateDTO.getAuthor())){
            return Result.fail().message("You are not authorized to update this article");
        }else if (articleUpdateDTO.getId() == null || articleUpdateDTO.getId() <= 0) {
            return Result.fail().message("Invalid article data");
        }

        Result<?> result = articleService.updateArticle(articleUpdateDTO);

        return result ;
    }


    /**
     * 根据文章ID更新文章状态<br>
     * 请求方式：PUT
     * @param articleId 文章ID
     * @param status 文章状态
     * @return Result<?> 成功或失败的信息
     */
    @Operation(
            summary = "更新文章状态",
            description = "根据文章ID更新文章的状态，如审核通过、审核不通过等，面向审核员使用<br>" +
                    "状态枚举：unreviewed（未审核）、approved（审核通过）、rejected（审核不通过）"
    )
    @PutMapping("/updateArticleStatus/{articleId}")
    public Result<?> updateArticleStatus(
            @PathVariable("articleId") Integer articleId,
            @RequestParam("status") Article.Status status) {
        if (articleId == null || articleId <= 0) {
            return Result.fail().message("Invalid article ID");
        }

        if (status == null) {
            return Result.fail().message("Invalid status");
        }

        boolean result = articleService.updateArticleStatus(articleId, status);
        return result ? Result.ok().message("Article status updated successfully") : Result.fail().message("Failed to update article status");
    }
}
