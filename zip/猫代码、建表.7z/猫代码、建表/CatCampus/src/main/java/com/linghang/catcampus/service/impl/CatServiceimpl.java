package com.linghang.catcampus.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.linghang.catcampus.mapper.CatMapper;
import com.linghang.catcampus.pojo.Cat;
import com.linghang.catcampus.pojo.Photo;
import com.linghang.catcampus.service.CatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service("catService")
@Transactional
public class CatServiceimpl extends ServiceImpl<CatMapper,Cat> implements CatService {
    @Autowired
    private CatMapper catMapper;


    @Override
    public boolean addCat(Cat cat) {
        return catMapper.insertCat(cat);
    }

    @Override
    public boolean updateCat(Cat cat) {
        return catMapper.updateCat(cat);
    }

    @Override
    public boolean deleteCat(int id) {
        return catMapper.deleteCat(id);
    }

    @Override
    public Cat info(int id) {
        return catMapper.selectCatById(id);
    }

    @Override
    public List<Cat> findByName(String name) {
        return catMapper.selectAllCats(name);
    }
    public boolean uploadCatWithPhotos(Cat cat, String coverImageUrl, List<String> photoUrls) {
        try {
            // 插入 Cat 信息
            boolean insertCatResult = catMapper.insertCat(cat);
            if (!insertCatResult) {
                throw new RuntimeException("Failed to insert cat");
            }

            Integer catId = cat.getId();

            // 保存封面图片
            if (coverImageUrl != null && !coverImageUrl.isEmpty()) {
                Photo photo = new Photo();
                photo.setPath(coverImageUrl);
                catMapper.saveCoverPhoto(photo);
                int id = photo.getId();
                // 这里可以根据需要更新 Cat 表的封面图片关联字段
            }

            // 保存其他图片
            if (photoUrls != null && !photoUrls.isEmpty()) {
                for (String photoUrl : photoUrls) {
                    catMapper.insertPhoto(catId, photoUrl);
                }
            }

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to upload cat with photos: " + e.getMessage());
        }
    }
}

