package com.linghang.catcampus.controller;

import com.aliyuncs.utils.StringUtils;
import com.linghang.catcampus.DTO.CatUploadDTO;
import com.linghang.catcampus.pojo.Cat;
import com.linghang.catcampus.service.CatService;
import com.linghang.catcampus.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/CatCampus/cat")
public class CatController {

    @Autowired
    private CatService catService;

    // 添加猫咪
    @PostMapping("/AddCats")
    public Result<?> addCat(@RequestBody Cat cat) {
        try {
            // 数据验证
            if (StringUtils.isEmpty(cat.getName())) {
                return Result.fail("猫咪名称不能为空");
            }

            boolean success = catService.addCat(cat);
            return success ? Result.ok("添加成功") : Result.fail("添加失败");
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail().code(500).message("服务器异常：" + e.getMessage());
        }
    }

    // 修改猫咪信息
    @PostMapping("/Update")
    public Result<?> update(@RequestBody Cat cat) {
        try {
            boolean success = catService.updateCat(cat);
            return success ? Result.ok("修改成功") : Result.fail("修改失败");
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail().code(500).message("服务器异常：" + e.getMessage());
        }
    }

    // 删除猫咪
    @PostMapping("/Delete")
    public Result<?> delete(@RequestParam("id") int id) {
        boolean success = catService.deleteCat(id);
        return success ? Result.ok("删除成功") : Result.fail("删除失败，ID不存在");
    }

    // 获取猫咪信息
    @GetMapping("/info")
    public Result<?> info(@RequestParam("id") int id) {
        Cat cat = catService.info(id);
        return cat != null ? Result.ok(cat) : Result.fail("未找到猫咪信息");
    }
    // 上传猫咪信息和相关图片
    @PostMapping("/uploadCatWithPhotos")
    public Result<?> uploadCatWithPhotos(@ModelAttribute CatUploadDTO catUploadDTO) {
        if (catUploadDTO == null) {
            return Result.fail().message("猫咪上传数据缺失");
        }

        if (catUploadDTO.getCat() == null) {
            return Result.fail().message("猫咪信息不能为空");
        }

        if (StringUtils.isEmpty(catUploadDTO.getCat().getName())) {
            return Result.fail().message("猫咪名称不能为空");
        }

        try {
            boolean result = catService.uploadCatWithPhotos(catUploadDTO.getCat(), catUploadDTO.getCoverImageUrl(), catUploadDTO.getPhotoUrls());
            return result ? Result.ok().message("猫咪信息和图片上传成功") : Result.fail().message("猫咪信息和图片上传失败");
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail().message("上传猫咪信息和图片时发生错误: " + e.getMessage());
        }
    }
}