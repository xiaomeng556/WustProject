package com.linghang.catcampus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.linghang.catcampus.pojo.Cat;
import com.linghang.catcampus.pojo.Photo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface CatMapper extends BaseMapper<Cat> {
    Cat selectCatById(@Param("id") int id);
    List<Cat> selectAllCats(@Param("name") String name);
    boolean insertCat(Cat cat);
    boolean updateCat(Cat cat);
    boolean deleteCat(int id);
    int insertPhoto(@Param("catId") Integer catId, @Param("path") String path);
    int saveCoverPhoto(Photo photo);
}
