package com.linghang.test.secondhandtransactions.configure;
import com.linghang.test.secondhandtransactions.utils.JwtAuthenticationFilter;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.AndRequestMatcher;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
    private final JwtAuthenticationFilter jwtFilter;

    public SecurityConfig(JwtAuthenticationFilter jwtFilter) {
        this.jwtFilter = jwtFilter;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        // 每个路径都用AntPathRequestMatcher包装
                        .requestMatchers(new AntPathRequestMatcher("/login")).permitAll()
                        .requestMatchers(
                                new AntPathRequestMatcher("/swagger-ui/**"),
                                new AntPathRequestMatcher("/v3/api-docs/**"),
                                new AntPathRequestMatcher("/swagger-resources/**"),
                                new AntPathRequestMatcher("/webjars/**"),
                                new AntPathRequestMatcher("/swagger-ui.html"),
                                new AntPathRequestMatcher("/loginController/login"),
                                new AntPathRequestMatcher("/publishController/publish"),
                                new AntPathRequestMatcher("/showController/all/**"),
                                new AntPathRequestMatcher("/showController/category/**"),
                                new AntPathRequestMatcher("/selectController/byNameAndIntroduce/**"),
                                new AntPathRequestMatcher("/selectController/byTypeOrStatus/**"),
                                new AntPathRequestMatcher("/userController/delete/**"),
                                new AntPathRequestMatcher("/userController/collection/"),
                                new AntPathRequestMatcher("/userController/collection/remove"),
                                 new AntPathRequestMatcher("/userController/collection/list"),
                                new AntPathRequestMatcher("/userController/collection/add"),
                                new AntPathRequestMatcher("/userController/update/**"),
                                new AntPathRequestMatcher("/userController/select/**")

                        ).permitAll()
                        .anyRequest().authenticated()
                )
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }
}
