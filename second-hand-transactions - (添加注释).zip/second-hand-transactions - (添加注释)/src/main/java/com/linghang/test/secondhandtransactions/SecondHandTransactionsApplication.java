package com.linghang.test.secondhandtransactions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondHandTransactionsApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecondHandTransactionsApplication.class, args);
    }

}
