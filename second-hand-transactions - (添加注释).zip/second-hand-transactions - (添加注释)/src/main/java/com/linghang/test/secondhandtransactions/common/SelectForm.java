package com.linghang.test.secondhandtransactions.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class SelectForm {
    private  String name;
    private  String introduce;

}
